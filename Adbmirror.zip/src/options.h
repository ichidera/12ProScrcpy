#pragma once
// Command-line options for adbmirror. Kept separate from main.cpp so
// argument parsing doesn't clutter the entry point.

#include <cstdio>
#include <cstring>
#include <string>

struct Options {
    std::string serial;    // adb -s <serial>, empty = default device
    std::string bitrate = "8M";
    std::string size;      // WIDTHxHEIGHT passthrough to screenrecord
    bool showHelpAndExit = false;
};

inline void printUsage() {
    std::printf(
        "adbmirror [-s SERIAL] [-b BITRATE] [-r WIDTHxHEIGHT]\n"
        "  -s SERIAL      target a specific adb device/emulator\n"
        "  -b BITRATE     screenrecord bitrate, e.g. 8M (default 8M)\n"
        "  -r WxH         cap capture resolution, e.g. 720x1600\n"
        "  F1             toggle cursor lock (locks AND hides the cursor)\n"
        "  F2             toggle fill (crop, no bars) / fit (letterboxed)\n"
        "  F3             toggle the left-edge control panel (volume/power/screenshot)\n"
        "  ESC            unlock cursor, or quit if already unlocked\n"
        "  Q              quit\n");
}

inline Options parseOptions(int argc, char** argv) {
    Options opt;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "-s") == 0 && i + 1 < argc) {
            opt.serial = argv[++i];
        } else if (std::strcmp(argv[i], "-b") == 0 && i + 1 < argc) {
            opt.bitrate = argv[++i];
        } else if (std::strcmp(argv[i], "-r") == 0 && i + 1 < argc) {
            opt.size = argv[++i];
        } else if (std::strcmp(argv[i], "-h") == 0 ||
                   std::strcmp(argv[i], "--help") == 0) {
            opt.showHelpAndExit = true;
        }
    }
    return opt;
}