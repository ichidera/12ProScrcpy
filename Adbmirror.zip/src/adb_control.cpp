#include "adb_control.h"

#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <thread>

namespace {

// --- device-specific mapping -----------------------------------------
// Physical hardware target `a010f622` (Qualcomm Waipio-class board).
// See docs/real-device-adb-sendevent.md section 2-3 and 10 for how
// these were found and confirmed working. Swap these three if this app
// is ever pointed at a different physical device.
struct KeyNode {
    const char* device;  // /dev/input/eventN
    int code;            // Linux evdev KEY_* code
};
constexpr KeyNode kVolumeUpNode{"/dev/input/event0", 115};    // gpio-keys
constexpr KeyNode kVolumeDownNode{"/dev/input/event3", 114};  // pmic_resin
constexpr KeyNode kPowerNode{"/dev/input/event2", 116};       // pmic_pwrkey

std::string adbPrefix(const std::string& serial) {
    return serial.empty() ? "adb " : ("adb -s " + serial + " ");
}

// Wraps `shellCmd` in `su -c "..."` and runs it as one adb invocation,
// blocking the calling (background) thread until it returns.
int runSu(const std::string& serial, const std::string& shellCmd) {
    std::string full = adbPrefix(serial) + "shell su -c \"" + shellCmd + "\"";
    return std::system(full.c_str());
}

// Runs the full down -> SYN_REPORT -> up -> SYN_REPORT sequence for one
// key node, re-asserting `setenforce 0` first since it doesn't survive
// a device reboot (see doc section 2) and costs nothing extra if the
// device is already permissive.
void injectKeyEvent(const std::string& serial, KeyNode node) {
    std::thread([serial, node] {
        runSu(serial, "setenforce 0");
        std::string base = std::string("sendevent ") + node.device + " ";
        std::string codeStr = std::to_string(node.code);
        runSu(serial, base + "1 " + codeStr + " 1");
        runSu(serial, base + "0 0 0");
        runSu(serial, base + "1 " + codeStr + " 0");
        runSu(serial, base + "0 0 0");
    }).detach();
}

std::string timestampedPngPath() {
    std::time_t t = std::time(nullptr);
    std::tm tm{};
#if defined(_WIN32)
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    char buf[64];
    std::snprintf(buf, sizeof(buf), "adbmirror-%04d%02d%02d-%02d%02d%02d.png",
                  tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour,
                  tm.tm_min, tm.tm_sec);

    // Screenshots go in a "screenshots" subfolder (relative to wherever
    // adbmirror is launched from) rather than dumping into the working
    // directory directly. Created on first use if it doesn't exist yet;
    // errors are ignored here on purpose - if creation genuinely failed,
    // the exec-out redirect right after this will fail too and that
    // failure is what actually gets reported back via onDone.
    std::filesystem::path dir("screenshots");
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);

    return (dir / buf).string();
}

}  // namespace

namespace adbctl {

void volumeUp(const std::string& serial) { injectKeyEvent(serial, kVolumeUpNode); }
void volumeDown(const std::string& serial) { injectKeyEvent(serial, kVolumeDownNode); }
void powerButton(const std::string& serial) { injectKeyEvent(serial, kPowerNode); }

void screenshot(const std::string& serial,
                 std::function<void(bool ok, std::string path)> onDone) {
    std::string path = timestampedPngPath();
    // `exec-out` streams the PNG bytes over stdout; the local shell
    // handles the redirect into a file. screencap doesn't need root on
    // this device, so this one stays on the plain (non-su) path.
    std::string cmd = adbPrefix(serial) + "exec-out screencap -p > \"" + path + "\"";
    std::thread([cmd, path, onDone] {
        int rc = std::system(cmd.c_str());
        if (onDone) onDone(rc == 0, path);
    }).detach();
}

}  // namespace adbctl
