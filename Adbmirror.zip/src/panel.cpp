#include "panel.h"

#include <algorithm>
#include <cmath>

#include "adb_control.h"

namespace {

bool pointInRect(const SDL_Rect& r, int x, int y) {
    SDL_Point p{x, y};
    return SDL_PointInRect(&p, &r) == SDL_TRUE;
}

void drawSpeakerIcon(SDL_Renderer* r, const SDL_Rect& box) {
    auto X = [&](float f) { return box.x + box.w * f; };
    auto Y = [&](float f) { return box.y + box.h * f; };
    SDL_FPoint pts[7] = {
        {X(0.05f),Y(0.38f)},{X(0.32f),Y(0.38f)},{X(0.58f),Y(0.12f)},
        {X(0.58f),Y(0.88f)},{X(0.32f),Y(0.62f)},{X(0.05f),Y(0.62f)},{X(0.05f),Y(0.38f)},
    };
    SDL_RenderDrawLinesF(r, pts, 7);
}
void drawPlus(SDL_Renderer* r, const SDL_Rect& box) {
    auto X=[&](float f){return box.x+box.w*f;}; auto Y=[&](float f){return box.y+box.h*f;};
    SDL_RenderDrawLineF(r,X(0.70f),Y(0.5f),X(0.98f),Y(0.5f));
    SDL_RenderDrawLineF(r,X(0.84f),Y(0.32f),X(0.84f),Y(0.68f));
}
void drawMinus(SDL_Renderer* r, const SDL_Rect& box) {
    auto X=[&](float f){return box.x+box.w*f;}; auto Y=[&](float f){return box.y+box.h*f;};
    SDL_RenderDrawLineF(r,X(0.70f),Y(0.5f),X(0.98f),Y(0.5f));
}
void drawPowerIcon(SDL_Renderer* r, const SDL_Rect& box) {
    float cx=box.x+box.w/2.f, cy=box.y+box.h/2.f+box.h*0.06f, radius=box.w*0.34f;
    SDL_FPoint prev{};
    for(int i=0;i<=20;++i){
        float deg=-60.f+(240.f+60.f)*i/20.f, rad=deg*3.14159265f/180.f;
        SDL_FPoint p{cx+radius*std::cos(rad),cy+radius*std::sin(rad)};
        if(i>0) SDL_RenderDrawLineF(r,prev.x,prev.y,p.x,p.y);
        prev=p;
    }
    SDL_RenderDrawLineF(r,cx,cy-radius*1.3f,cx,cy-radius*0.1f);
}
void drawScreenshotIcon(SDL_Renderer* r, const SDL_Rect& box) {
    float m=box.w*0.10f,len=box.w*0.32f;
    float x0=box.x+m,y0=box.y+m,x1=box.x+box.w-m,y1=box.y+box.h-m;
    SDL_RenderDrawLineF(r,x0,y0,x0+len,y0); SDL_RenderDrawLineF(r,x0,y0,x0,y0+len);
    SDL_RenderDrawLineF(r,x1,y0,x1-len,y0); SDL_RenderDrawLineF(r,x1,y0,x1,y0+len);
    SDL_RenderDrawLineF(r,x0,y1,x0+len,y1); SDL_RenderDrawLineF(r,x0,y1,x0,y1-len);
    SDL_RenderDrawLineF(r,x1,y1,x1-len,y1); SDL_RenderDrawLineF(r,x1,y1,x1,y1-len);
}
void drawKeymapIcon(SDL_Renderer* r, const SDL_Rect& box) {
    auto X=[&](float f){return box.x+box.w*f;}; auto Y=[&](float f){return box.y+box.h*f;};
    // 2x2 grid
    SDL_RenderDrawLineF(r,X(0.1f),Y(0.1f),X(0.9f),Y(0.1f));
    SDL_RenderDrawLineF(r,X(0.1f),Y(0.55f),X(0.9f),Y(0.55f));
    SDL_RenderDrawLineF(r,X(0.1f),Y(0.9f),X(0.9f),Y(0.9f));
    SDL_RenderDrawLineF(r,X(0.1f),Y(0.1f),X(0.1f),Y(0.9f));
    SDL_RenderDrawLineF(r,X(0.5f),Y(0.1f),X(0.5f),Y(0.9f));
    SDL_RenderDrawLineF(r,X(0.9f),Y(0.1f),X(0.9f),Y(0.9f));
    // cursor arrow in top-left cell
    float ax=X(0.18f),ay=Y(0.18f),aw=box.w*0.18f,ah=box.h*0.24f;
    SDL_RenderDrawLineF(r,ax,ay,ax,ay+ah);
    SDL_RenderDrawLineF(r,ax,ay,ax+aw,ay+ah*0.6f);
    SDL_RenderDrawLineF(r,ax,ay+ah,ax+aw*0.5f,ay+ah*0.75f);
}

} // namespace

Panel::Panel() = default;

SDL_Rect Panel::panelRect(int windowH) const {
    return SDL_Rect{static_cast<int>(offsetX_)-kPanelWidth,0,kPanelWidth,windowH};
}
SDL_Rect Panel::tabRect(int windowH) const {
    return SDL_Rect{static_cast<int>(offsetX_),(windowH-kTabHeight)/2,kTabWidth,kTabHeight};
}
SDL_Rect Panel::buttonRect(int index, int windowH) const {
    int totalH=kButtonCount*kButtonSize+(kButtonCount-1)*kButtonGap;
    int startY=(windowH-totalH)/2;
    SDL_Rect panel=panelRect(windowH);
    return SDL_Rect{panel.x+(kPanelWidth-kButtonSize)/2,
                    startY+index*(kButtonSize+kButtonGap),
                    kButtonSize,kButtonSize};
}
int Panel::hitTestButton(int mx,int my,int wh) const {
    for(int i=0;i<kButtonCount;++i) if(pointInRect(buttonRect(i,wh),mx,my)) return i;
    return -1;
}
void Panel::activate(Button b) {
    switch(b){
        case Button::kVolumeUp:   adbctl::volumeUp(serial_);   break;
        case Button::kVolumeDown: adbctl::volumeDown(serial_);  break;
        case Button::kPower:      adbctl::powerButton(serial_); break;
        case Button::kScreenshot:{
            auto fu=screenshotFlashUntilMs_; auto fo=screenshotFlashOk_;
            adbctl::screenshot(serial_,[fu,fo](bool ok,std::string){
                fo->store(ok); fu->store(SDL_GetTicks()+900);
            }); break;
        }
        case Button::kKeymap:
            keymapFlashUntilMs_.store(SDL_GetTicks()+300);
            if(keymapCb_) keymapCb_();
            break;
        case Button::kCount: break;
    }
}
void Panel::toggle(){open_=!open_;}
bool Panel::handleEvent(const SDL_Event& e,int windowW,int windowH){
    (void)windowW;
    switch(e.type){
        case SDL_MOUSEMOTION:
            hoveredButton_=hitTestButton(e.motion.x,e.motion.y,windowH); return false;
        case SDL_MOUSEBUTTONDOWN:{
            if(e.button.button!=SDL_BUTTON_LEFT) return false;
            if(pointInRect(tabRect(windowH),e.button.x,e.button.y)){tabPressed_=true;return true;}
            int idx=hitTestButton(e.button.x,e.button.y,windowH);
            if(idx!=-1){pressedButton_=idx;return true;} return false;
        }
        case SDL_MOUSEBUTTONUP:{
            if(e.button.button!=SDL_BUTTON_LEFT) return false;
            if(tabPressed_){
                tabPressed_=false;
                if(pointInRect(tabRect(windowH),e.button.x,e.button.y)) toggle();
                return true;
            }
            if(pressedButton_!=-1){
                int idx=hitTestButton(e.button.x,e.button.y,windowH);
                if(idx==pressedButton_) activate(static_cast<Button>(idx));
                pressedButton_=-1; return true;
            }
            return false;
        }
        default: return false;
    }
}
void Panel::update(uint32_t nowMs){
    uint32_t dt=lastUpdateMs_==0?0:nowMs-lastUpdateMs_; lastUpdateMs_=nowMs;
    float target=open_?static_cast<float>(kPanelWidth):0.f;
    float step=kSlideSpeed*(dt/1000.f);
    if(offsetX_<target) offsetX_=std::min(offsetX_+step,target);
    else if(offsetX_>target) offsetX_=std::max(offsetX_-step,target);
}
void Panel::render(SDL_Renderer* renderer,int windowW,int windowH){
    (void)windowW;
    SDL_Rect panel=panelRect(windowH), tab=tabRect(windowH);
    SDL_SetRenderDrawColor(renderer,24,26,32,235); SDL_RenderFillRect(renderer,&panel);
    SDL_SetRenderDrawColor(renderer,60,64,74,255);
    SDL_RenderDrawLine(renderer,panel.x+panel.w-1,panel.y,panel.x+panel.w-1,panel.y+panel.h);
    SDL_SetRenderDrawColor(renderer,42,45,53,255); SDL_RenderFillRect(renderer,&tab);
    SDL_SetRenderDrawColor(renderer,150,155,165,255);
    float tcx=tab.x+tab.w*0.5f,tcy=tab.y+tab.h*0.5f,dir=open_?-1.f:1.f;
    SDL_RenderDrawLineF(renderer,tcx-3*dir,tcy-8,tcx+3*dir,tcy);
    SDL_RenderDrawLineF(renderer,tcx-3*dir,tcy+8,tcx+3*dir,tcy);

    uint32_t now=SDL_GetTicks();
    bool ssFlash=now<screenshotFlashUntilMs_->load();
    bool kmFlash=now<keymapFlashUntilMs_.load();

    for(int i=0;i<kButtonCount;++i){
        SDL_Rect btn=buttonRect(i,windowH);
        bool hov=hoveredButton_==i, prs=pressedButton_==i;
        SDL_Color bg=prs?SDL_Color{70,74,86,255}:hov?SDL_Color{54,58,68,255}:SDL_Color{40,43,50,255};
        if(i==static_cast<int>(Button::kScreenshot)&&ssFlash)
            bg=screenshotFlashOk_->load()?SDL_Color{40,110,60,255}:SDL_Color{120,45,45,255};
        if(i==static_cast<int>(Button::kKeymap)&&kmFlash)
            bg=SDL_Color{60,80,140,255};
        SDL_SetRenderDrawColor(renderer,bg.r,bg.g,bg.b,bg.a);
        SDL_RenderFillRect(renderer,&btn);
        SDL_SetRenderDrawColor(renderer,90,95,105,255); SDL_RenderDrawRect(renderer,&btn);

        SDL_Rect icon{btn.x+8,btn.y+8,btn.w-16,btn.h-16};
        switch(static_cast<Button>(i)){
            case Button::kVolumeUp:
                SDL_SetRenderDrawColor(renderer,225,228,232,255);
                drawSpeakerIcon(renderer,icon); drawPlus(renderer,icon); break;
            case Button::kVolumeDown:
                SDL_SetRenderDrawColor(renderer,225,228,232,255);
                drawSpeakerIcon(renderer,icon); drawMinus(renderer,icon); break;
            case Button::kPower:
                SDL_SetRenderDrawColor(renderer,225,228,232,255);
                drawPowerIcon(renderer,icon); break;
            case Button::kScreenshot:
                SDL_SetRenderDrawColor(renderer,225,228,232,255);
                drawScreenshotIcon(renderer,icon); break;
            case Button::kKeymap:
                SDL_SetRenderDrawColor(renderer,120,160,255,255); // blue icon
                drawKeymapIcon(renderer,icon); break;
            case Button::kCount: break;
        }
    }
}
