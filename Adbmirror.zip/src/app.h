#pragma once
#include <SDL.h>
#include <string>
#include "capturer.h"
#include "frame_buffer.h"
#include "keymap_controller.h"
#include "keymap_editor.h"
#include "panel.h"

class App {
public:
    App();
    ~App();
    App(const App&) = delete;
    App& operator=(const App&) = delete;

    bool init();
    int  run(FrameBuffer& frameBuffer, const Capturer& capturer);

private:
    void handleKeyDown(SDL_Keycode key);
    void setCursorLocked(bool locked);
    void uploadFrame(const FrameBuffer::View& view);
    void renderFrame();
    void updateTitle(const Capturer& capturer, unsigned fps);

    // Compute the current video draw rect in renderer pixels.
    // Fills vx,vy,vw,vh; called each frame and whenever window changes.
    // `fill`: true = scale to cover (crop overflow), false = scale to fit
    // (letterboxed, nothing ever hidden). Passed explicitly rather than
    // reading fillMode_ directly so the keymap editor can force "fit"
    // regardless of the user's normal preference - see run().
    void computeVideoRect(int winW, int winH, bool fill,
                          int& vx, int& vy, int& vw, int& vh) const;

    // Open / close the keymap editor.
    void openKeymapEditor();
    void closeKeymapEditor();

    // Detect the foreground package on the device (polls every 2 s).
    void pollForegroundPackage();
    void applyProfile(const std::string& packageName);

    // Detect the device's current display rotation (polls alongside the
    // foreground package - see run()) so injected touches can be rotated
    // to match, since raw sendevent doesn't get Android's own rotation
    // compensation the way a real touch does (see TouchInjector).
    void pollRotation();

    SDL_Window*   window_   = nullptr;
    SDL_Renderer* renderer_ = nullptr;
    SDL_Texture*  texture_  = nullptr;
    int texW_ = 0, texH_ = 0;
    // texW_/texH_ from the previous frame we saw, so run() can detect a
    // device rotation (aspect ratio flip) and resize the window to match
    // it, the same way scrcpy follows the device's orientation. Without
    // this, a rotation can leave the window sized for the old orientation
    // and "fill" mode crops away most of the new, differently-shaped frame.
    int prevTexW_ = 0, prevTexH_ = 0;

    Panel            panel_;
    KeymapController kmController_{""}; // serial set in run()
    KeymapEditor     kmEditor_;

    int   appliedExtraPx_ = 0;
    bool  running_        = true;
    bool  cursorLocked_   = false;
    bool  fillMode_       = true;
    bool  keymapActive_   = false;  // true when a profile is loaded & editor closed
    bool  editorOpen_     = false;

    // Current foreground package (used to auto-switch profiles).
    std::string currentPackage_;
    uint32_t    lastPackagePollMs_ = 0;
    std::string serial_;  // stored so pollForegroundPackage can use it

    // Current display rotation (0/1/2/3 = 0/90/180/270°). Fed into
    // kmController_.setRotation() whenever it changes - see pollRotation().
    int      currentRotation_    = 0;
    uint32_t lastRotationPollMs_ = 0;
};
