#pragma once
// touch_injector.h — Type-B multitouch injection for /dev/input/event6 (fts).
//
// Every protocol detail is taken directly from
// docs/real-device-adb-sendevent.md.  Nothing is guessed there.
//
// Key facts from the doc:
//   Device   /dev/input/event6  (FocalTech fts, SPI bus)            §3
//   Protocol Type B — no SYN_MT_REPORT; one SYN_REPORT per frame    §4
//   Ranges   X 0–14399, Y 0–31999                                   §1 §4
//   Slots    0–9 (10 simultaneous contacts)                          §4
//   BTN_TOUCH required — driver uses hover-sensing, needs explicit   §11
//             touch flag to distinguish contact from hover
//
// Evdev codes (standard Linux input.h):
//   EV_SYN=0, EV_KEY=1, EV_ABS=3
//   ABS_MT_SLOT=47, ABS_MT_TRACKING_ID=57
//   ABS_MT_POSITION_X=53, ABS_MT_POSITION_Y=54
//   BTN_TOUCH=330, SYN_REPORT=0
//
// SLOT ASSIGNMENT (avoid per-gesture conflicts):
//   0–3 — DPad up/down/left/right (each its own persistent contact,
//         via the same generic hold mechanism as any other HoldButton -
//         see holdDown()/holdUp() below and DPadDir in keymap_types.h)
//   4 — AimPan / camera contact
//   5 — ShootButton / TapPoint fire
//   6–9 — additional TapPoint / HoldButton bindings
//
// ROTATION: this device's raw touch axes are fixed to its NATIVE
// (portrait) orientation - the doc's X/Y ranges were measured with the
// device unrotated. Real touches still land correctly when the
// foreground app is in landscape because Android's InputReader rotates
// raw coordinates to match the current display orientation before an
// app ever sees them. Raw sendevent bypasses that entirely, so *we*
// have to apply the same rotation ourselves - see setRotation()/
// toRawX()/toRawY() below - or a point placed on the video while the
// screen is rotated lands in the wrong place once actually injected.
//
// INJECTION STRATEGY:
//   One-shot (tap, swipe):
//     Build the full sendevent sequence as a flat semicolon-joined string
//     → one `adb shell su -c "..."` call on a detached thread.
//     (Doc §11: shell loops inside su -c break with some host shells;
//      semicolons in a flat single-command string are safe.)
//
//   Real-time (DPad directions held, AimPan tracking):
//     Open a persistent `adb shell su` via popen() in write mode.
//     Write "sendevent … \n" lines as events arrive.
//     The shell processes them instantly — no new ADB handshake per event.
//     Close with "exit\n" + pclose() on key/mouse release.

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>

#ifdef _WIN32
#  include <fcntl.h>
#  include <io.h>
#  define POPEN  _popen
#  define PCLOSE _pclose
#else
#  define POPEN  popen
#  define PCLOSE pclose
#endif

class TouchInjector {
public:
    // ── device constants (doc §1, §4) ────────────────────────────────────────
    static constexpr const char* kTouchDev = "/dev/input/event6";
    static constexpr int kMaxX = 14399;
    static constexpr int kMaxY = 31999;

    // ── slot assignments ─────────────────────────────────────────────────────
    static constexpr int kSlotDPadUp    = 0;
    static constexpr int kSlotDPadDown  = 1;
    static constexpr int kSlotDPadLeft  = 2;
    static constexpr int kSlotDPadRight = 3;
    static constexpr int kSlotAim       = 4;
    static constexpr int kSlotShoot     = 5;
    static constexpr int kSlotBase      = 6;   // extra tap/hold buttons: 6..9

    explicit TouchInjector(std::string serial) : serial_(std::move(serial)) {}

    // Move-assign: only safe after releaseAll() has been called on the old instance
    // (all shells closed, no background threads touching members).
    // std::mutex is not movable, so we reassign only the non-mutex state.
    TouchInjector& operator=(TouchInjector&& o) noexcept {
        if (this == &o) return *this;
        // Shells must already be closed by the caller before move-assigning.
        serial_       = std::move(o.serial_);
        tidCounter_.store(o.tidCounter_.load());
        rotation_.store(o.rotation_.load());
        // mutex, FILE*, atomic<bool> state all stay default (shells closed).
        return *this;
    }

    ~TouchInjector() {
        closeAimShell();
        // close any open hold shells (this also covers the 4 DPad slots -
        // they're just regular hold shells now, see holdDown()/holdUp())
        std::lock_guard<std::mutex> lg(holdMtx_);
        for (auto& [slot, sh] : holdShells_) {
            if (sh) { std::fprintf(sh,"exit\n"); std::fflush(sh); PCLOSE(sh); }
        }
        holdShells_.clear();
    }

    // ── rotation ──────────────────────────────────────────────────────────────
    // r: 0=natural(portrait), 1=90°, 2=180°, 3=270° - Android's Surface.ROTATION_*
    // convention. Polled from the device (see App::pollRotation) since raw
    // sendevent doesn't get this for free the way a real touch would.
    void setRotation(int r) { rotation_.store(std::clamp(r,0,3)); }
    int  rotation() const { return rotation_.load(); }

    // ── coordinate conversion ────────────────────────────────────────────────
    // nx,ny: normalised [0..1] position within the CURRENTLY DISPLAYED (i.e.
    // already-rotated) video frame - exactly what every binding stores and
    // what the editor places points against. Converts to raw touch-panel
    // coordinates by applying the inverse of whichever rotation Android is
    // currently applying in the other direction, so the two cancel out and
    // the touch lands where it visually appears in the mirrored frame.
    //
    // NOTE: this assumes the standard Android raw->logical rotation mapping.
    // If a placed point still lands wrong after this, it almost always means
    // the rotation *sign* is flipped for this device/build - swap the r==1
    // and r==3 cases below (they're each other's mirror image) rather than
    // re-deriving the whole thing.
    int toRawX(float nx, float ny) const {
        float f;
        switch (rotation_.load()) {
            case 1:  f = 1.f-ny; break;   // ROTATION_90
            case 2:  f = 1.f-nx; break;   // ROTATION_180
            case 3:  f = ny;     break;   // ROTATION_270
            default: f = nx;    break;    // ROTATION_0 (natural/portrait)
        }
        return std::clamp((int)std::lround(f*kMaxX),0,kMaxX);
    }
    int toRawY(float nx, float ny) const {
        float f;
        switch (rotation_.load()) {
            case 1:  f = nx;     break;
            case 2:  f = 1.f-ny; break;
            case 3:  f = 1.f-nx; break;
            default: f = ny;    break;
        }
        return std::clamp((int)std::lround(f*kMaxY),0,kMaxY);
    }

    // ── ONE-SHOT: tap (doc §6) ────────────────────────────────────────────────
    void tap(float nx, float ny, int slot=kSlotShoot, int durMs=50) {
        int tx=toRawX(nx,ny), ty=toRawY(nx,ny), tid=nextTid();
        std::string s=serial_;
        std::thread([=]{
            runSu(s, flat(seDown(slot,tid,tx,ty)));
            std::this_thread::sleep_for(std::chrono::milliseconds(durMs));
            runSu(s, flat(seUp(slot)));
        }).detach();
    }

    // ── ONE-SHOT: swipe (doc §7) ─────────────────────────────────────────────
    void swipe(float nx1,float ny1,float nx2,float ny2,
               int durMs=150,int steps=15,int slot=kSlotShoot) {
        int x1=toRawX(nx1,ny1),y1=toRawY(nx1,ny1);
        int x2=toRawX(nx2,ny2),y2=toRawY(nx2,ny2);
        int tid=nextTid();
        int stepMs=std::max(1,durMs/std::max(1,steps));
        std::string s=serial_;
        std::thread([=]{
            runSu(s, flat(seDown(slot,tid,x1,y1)));
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
            for(int i=1;i<=steps;++i){
                float t=(float)i/steps;
                runSu(s, flat(seMove(slot,(int)(x1+(x2-x1)*t),(int)(y1+(y2-y1)*t))));
                std::this_thread::sleep_for(std::chrono::milliseconds(stepMs));
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
            runSu(s, flat(seUp(slot)));
        }).detach();
    }

    // ── AIM PAN (persistent shell) ────────────────────────────────────────────
    // aimOpen(): cursor just locked, place the initial contact.
    // aimMove(): called on every SDL_MOUSEMOTION while locked.
    //   dxPx/dyPx — SDL xrel/yrel in screen pixels
    //   videoW/videoH — pixel size of the video rectangle on screen
    // aimClose(): cursor unlocked or binding deactivated.
    void aimOpen(float centerNX, float centerNY) {
        std::lock_guard<std::mutex> lg(aimMtx_);
        aimCX_=centerNX; aimCY_=centerNY;
        aimX_ =centerNX; aimY_ =centerNY;
        aimShell_=openShell();
        if (!aimShell_) return;
        aimTid_=nextTid();
        writeShell(aimShell_, seDown(kSlotAim,aimTid_,toRawX(aimCX_,aimCY_),toRawY(aimCX_,aimCY_)));
        aimActive_=true;
    }

    void aimMove(int dxPx, int dyPx, float sensitivity, float clampRadius,
                 float videoW, float videoH) {
        std::lock_guard<std::mutex> lg(aimMtx_);
        if (!aimShell_||!aimActive_) return;
        float ndx=(float)dxPx/videoW*sensitivity;
        float ndy=(float)dyPx/videoH*sensitivity;
        aimX_+=ndx; aimY_+=ndy;
        float ox=aimX_-aimCX_, oy=aimY_-aimCY_;
        float d=std::sqrt(ox*ox+oy*oy);
        if (d>clampRadius) { float sc=clampRadius/d; ox*=sc; oy*=sc; }
        aimX_=std::clamp(aimCX_+ox,0.f,1.f);
        aimY_=std::clamp(aimCY_+oy,0.f,1.f);
        writeShell(aimShell_, seMove(kSlotAim,toRawX(aimX_,aimY_),toRawY(aimX_,aimY_)));
    }

    void aimClose() {
        std::lock_guard<std::mutex> lg(aimMtx_);
        if (!aimShell_) return;
        writeShell(aimShell_, seUp(kSlotAim));
        closeAimShellLocked();
        aimActive_=false;
    }

    bool isAimActive() const { return aimActive_.load(); }

    // ── HOLD BUTTON (persistent shell per slot) ───────────────────────────────
    // Generic sustained touch-down at (nx,ny) on `slot` until holdUp(slot).
    // Used for HoldButton bindings AND, as of the DPad rework, for each of
    // the 4 DPad directions too (kSlotDPadUp..kSlotDPadRight) - a direction
    // held is just a hold-button at its own point, nothing more special.
    void holdDown(float nx, float ny, int slot) {
        int tx=toRawX(nx,ny), ty=toRawY(nx,ny), tid=nextTid();
        {
            std::lock_guard<std::mutex> lg(holdMtx_);
            if (holdShells_.count(slot)) return;
            FILE* sh=openShell();
            if (!sh) return;
            holdShells_[slot]=sh;
            writeShell(sh, seDown(slot,tid,tx,ty));
        }
        // micro-jitter thread (doc §8 note: some UIs watch for movement to
        // distinguish a held finger from a stuck sensor)
        std::thread([this,slot,tx,ty]{
            while(true){
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                std::lock_guard<std::mutex> lg(holdMtx_);
                auto it=holdShells_.find(slot);
                if(it==holdShells_.end()) break;
                writeShell(it->second, seMove(slot,tx,ty));
            }
        }).detach();
    }

    void holdUp(int slot) {
        std::lock_guard<std::mutex> lg(holdMtx_);
        auto it=holdShells_.find(slot);
        if(it==holdShells_.end()) return;
        writeShell(it->second, seUp(slot));
        std::fprintf(it->second,"exit\n"); std::fflush(it->second);
        PCLOSE(it->second);
        holdShells_.erase(it);
    }

private:
    std::string serial_;
    std::atomic<int> tidCounter_{1};
    std::atomic<int> rotation_{0};

    // aim
    mutable std::mutex aimMtx_;
    FILE* aimShell_=nullptr;
    int   aimTid_=0;
    float aimCX_=0.5f,aimCY_=0.5f,aimX_=0.5f,aimY_=0.5f;
    std::atomic<bool> aimActive_{false};

    // hold buttons (also covers the 4 DPad direction slots - see holdDown())
    mutable std::mutex holdMtx_;
    std::unordered_map<int,FILE*> holdShells_;

    // ── internals ────────────────────────────────────────────────────────────
    int nextTid() { return tidCounter_.fetch_add(1)%65535+1; }

    // Open an interactive su shell and assert setenforce 0 (doc §2).
    FILE* openShell() const {
        std::string cmd = serial_.empty()
            ? "adb shell su"
            : ("adb -s "+serial_+" shell su");
#ifdef _WIN32
        FILE* sh=_popen(cmd.c_str(),"wb");
        if(sh) _setmode(_fileno(sh),_O_BINARY);
#else
        FILE* sh=popen(cmd.c_str(),"w");
#endif
        if(!sh) return nullptr;
        // Re-assert every session — setenforce 0 reverts on reboot (doc §2).
        std::fprintf(sh,"setenforce 0\n"); std::fflush(sh);
        return sh;
    }

    // Run a one-shot su -c "…" (flat semicolons, no shell loops — doc §11).
    static void runSu(const std::string& serial, const std::string& cmd) {
        std::string full=(serial.empty()?"adb ":"adb -s "+serial+" ")
                         +"shell su -c \""+cmd+"\"";
        int rc = std::system(full.c_str());
        (void)rc;
    }

    static void writeShell(FILE* sh, const std::string& cmds) {
        std::fprintf(sh,"%s\n",cmds.c_str()); std::fflush(sh);
    }

    void closeAimShellLocked() {    // call under aimMtx_
        if(!aimShell_) return;
        std::fprintf(aimShell_,"exit\n"); std::fflush(aimShell_);
        PCLOSE(aimShell_); aimShell_=nullptr;
    }
    void closeAimShell()  { std::lock_guard<std::mutex> lg(aimMtx_);  closeAimShellLocked(); }

    // ── sendevent command builders ────────────────────────────────────────────
    // These produce newline-separated multi-line strings for persistent shells,
    // or semicolon-flat strings (via flat()) for one-shot runSu().

    // ABS_MT_SLOT, TRACKING_ID, BTN_TOUCH=1, X, Y, SYN  (doc §5 Real-TouchDown)
    static std::string seDown(int slot,int tid,int tx,int ty) {
        char b[256];
        std::snprintf(b,sizeof(b),
            "sendevent %s 3 47 %d\n"   // ABS_MT_SLOT
            "sendevent %s 3 57 %d\n"   // ABS_MT_TRACKING_ID
            "sendevent %s 1 330 1\n"   // BTN_TOUCH down
            "sendevent %s 3 53 %d\n"   // ABS_MT_POSITION_X
            "sendevent %s 3 54 %d\n"   // ABS_MT_POSITION_Y
            "sendevent %s 0 0 0",      // SYN_REPORT
            kTouchDev,slot, kTouchDev,tid,
            kTouchDev,      kTouchDev,tx, kTouchDev,ty, kTouchDev);
        return b;
    }

    // SLOT, X, Y, SYN  (doc §5 Real-TouchMove)
    static std::string seMove(int slot,int tx,int ty) {
        char b[192];
        std::snprintf(b,sizeof(b),
            "sendevent %s 3 47 %d\n"
            "sendevent %s 3 53 %d\n"
            "sendevent %s 3 54 %d\n"
            "sendevent %s 0 0 0",
            kTouchDev,slot, kTouchDev,tx, kTouchDev,ty, kTouchDev);
        return b;
    }

    // SLOT, TRACKING_ID=-1, BTN_TOUCH=0, SYN  (doc §5 Real-TouchUp)
    static std::string seUp(int slot) {
        char b[192];
        std::snprintf(b,sizeof(b),
            "sendevent %s 3 47 %d\n"
            "sendevent %s 3 57 -1\n"   // TRACKING_ID -1 = lift
            "sendevent %s 1 330 0\n"   // BTN_TOUCH up
            "sendevent %s 0 0 0",
            kTouchDev,slot, kTouchDev, kTouchDev, kTouchDev);
        return b;
    }

    // Convert \n → ; for single su -c "..." invocations (doc §11).
    static std::string flat(const std::string& s) {
        std::string r; r.reserve(s.size());
        for (char c:s) r+=(c=='\n'?';':c);
        return r;
    }
};
