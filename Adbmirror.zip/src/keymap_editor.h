#pragma once
// keymap_editor.h — SDL overlay for viewing and editing the active KeyProfile.
//
// Drawn on top of the mirror texture by App after renderFrame().
// When editorOpen_ == true, App routes events here *before* KeymapController,
// so clicks place / select bindings instead of firing them.
//
// Layout of the edit overlay:
//   • Each binding: coloured circle at its center (colour = type), label, key hint.
//   • Selected binding: highlighted ring + small toolbar at bottom of screen:
//       [Delete]  [Type ↕]  [Key: press any]  [Sensitivity ↕ (aim only)]  [Done]
//   • Clicking empty space: opens a "Add binding" picker (type list).
//   • Dragging a binding circle: repositions it (updates center.x/y in normalised coords).
//
// Everything is drawn with SDL primitives (lines, rects, filled rects) —
// no font assets.  Labels use a tiny 5×7 pixel bitmap font drawn inline.

#include "keymap_types.h"
#include "keymap_store.h"

#include <SDL.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <functional>
#include <string>
#include <vector>

class KeymapEditor {
public:
    // Callback: called when the editor saves (close button or Escape).
    // The caller (App) should then call controller.setProfile(newProfile).
    using SaveCallback = std::function<void(const KeyProfile&)>;

    KeymapEditor() = default;

    bool isOpen() const { return open_; }

    void open(const KeyProfile& profile, SaveCallback cb) {
        profile_  = profile;
        cb_       = std::move(cb);
        open_     = true;
        selected_ = -1;
        selectedDpadDir_ = -1;
        dragging_ = false;
        addMode_  = false;
        waitKey_  = false;
    }

    void close() {
        if (open_ && cb_) cb_(profile_);
        open_     = false;
        dragging_ = false;
        waitKey_  = false;
        addMode_  = false;
    }

    // Returns true if the event was consumed by the editor.
    bool handleEvent(const SDL_Event& e, int vx, int vy, int vw, int vh) {
        if (!open_) return false;
        vx_=vx; vy_=vy; vw_=vw; vh_=vh;

        switch (e.type) {
            case SDL_KEYDOWN:
                return onKeyDown(e.key.keysym.sym);
            case SDL_MOUSEBUTTONDOWN:
                if (e.button.button==SDL_BUTTON_LEFT)
                    return onLMBDown(e.button.x, e.button.y);
                return false;
            case SDL_MOUSEBUTTONUP:
                if (e.button.button==SDL_BUTTON_LEFT)
                    return onLMBUp(e.button.x, e.button.y);
                return false;
            case SDL_MOUSEMOTION:
                return onMouseMove(e.motion.x, e.motion.y);
            default:
                return false;
        }
    }

    void render(SDL_Renderer* r, int vx, int vy, int vw, int vh) {
        if (!open_) return;
        vx_=vx; vy_=vy; vw_=vw; vh_=vh;

        // Semi-transparent dark tint over the video area.
        SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(r,0,0,0,120);
        SDL_Rect tint{vx,vy,vw,vh};
        SDL_RenderFillRect(r,&tint);
        SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);

        // Draw each binding.
        for (int i=0;i<(int)profile_.bindings.size();++i)
            drawBinding(r, i, i==selected_);

        // Bottom toolbar when a binding is selected.
        if (selected_>=0 && selected_<(int)profile_.bindings.size())
            drawToolbar(r, selected_);

        // "Add" mode picker.
        if (addMode_)
            drawAddPicker(r);

        // Header hint.
        drawRect(r, vx+4,vy+4, vw-8,20, {20,22,28,220});
        drawText(r, "KEYMAP EDIT — click to place, drag to move, ESC to save",
                 vx+8, vy+8, {200,210,220,255});
    }

private:
    KeyProfile   profile_;
    SaveCallback cb_;
    bool open_     = false;
    bool dragging_ = false;
    bool addMode_  = false;
    bool waitKey_  = false;    // waiting for a key press to assign to selected_
    int  selected_ = -1;
    // Which DPad direction (DPadDir, or -1) is selected within
    // profile_.bindings[selected_] - only meaningful when that binding's
    // type is DPad. Every other binding type leaves this at -1.
    int  selectedDpadDir_ = -1;
    int  dragOffX_ = 0, dragOffY_ = 0;
    BindingType addType_ = BindingType::TapPoint;

    // Current video rect (pixels).
    int vx_=0,vy_=0,vw_=1,vh_=1;

    // ── coordinate helpers ───────────────────────────────────────────────────
    int toSX(float nx) const { return vx_+(int)(nx*vw_); }
    int toSY(float ny) const { return vy_+(int)(ny*vh_); }
    float toNX(int px) const { return vw_>0?(float)(px-vx_)/vw_:0.5f; }
    float toNY(int py) const { return vh_>0?(float)(py-vy_)/vh_:0.5f; }

    // ── type meta ────────────────────────────────────────────────────────────
    struct TypeMeta { const char* name; SDL_Color color; };
    static TypeMeta meta(BindingType t) {
        switch(t){
            case BindingType::TapPoint:    return {"TAP",      {80,160,255,255}};
            case BindingType::DPad:        return {"DPAD",     {100,220,100,255}};
            case BindingType::AimPan:      return {"AIM",      {255,180,60,255}};
            case BindingType::ShootButton: return {"SHOOT",    {255,80,80,255}};
            case BindingType::AimAndShoot: return {"AIM+SHOOT",{220,100,220,255}};
            case BindingType::HoldButton:  return {"HOLD",     {255,200,0,255}};
            case BindingType::Swipe:       return {"SWIPE",    {0,210,200,255}};
        }
        return {"?",{200,200,200,255}};
    }

    // ── drawing helpers (SDL primitives only) ────────────────────────────────
    static void drawRect(SDL_Renderer* r, int x,int y,int w,int h,SDL_Color c) {
        SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);
        SDL_Rect rc{x,y,w,h}; SDL_RenderFillRect(r,&rc);
        SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);
    }
    static void drawOutlineRect(SDL_Renderer* r,int x,int y,int w,int h,SDL_Color c) {
        SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);
        SDL_Rect rc{x,y,w,h}; SDL_RenderDrawRect(r,&rc);
    }
    static void drawCircle(SDL_Renderer* r, int cx,int cy,int rad,SDL_Color c,bool fill) {
        SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);
        for(int dy=-rad;dy<=rad;++dy){
            int dx=(int)std::sqrt((float)(rad*rad-dy*dy));
            if(fill) SDL_RenderDrawLine(r,cx-dx,cy+dy,cx+dx,cy+dy);
            else { SDL_RenderDrawPoint(r,cx-dx,cy+dy); SDL_RenderDrawPoint(r,cx+dx,cy+dy); }
        }
    }

    // Minimal 3×5 pixel font — draws ASCII chars as tiny dots.
    // Each char is 4 wide × 6 tall.  Enough for labels.
    static void drawChar(SDL_Renderer* r, char ch, int x, int y, SDL_Color c) {
        // 3-wide, 5-tall bitmaps for A-Z, 0-9, space, colon, +, -, ., ,
        static const std::pair<char,uint16_t> glyphs[] = {
            {' ',0x0000},{'0',0x7B6F},{'1',0x2C97},{'2',0x73E7},{'3',0x73CF},
            {'4',0x5BC9},{'5',0x79CF},{'6',0x79EF},{'7',0x7292},{'8',0x7BEF},
            {'9',0x7BCF},{'A',0x2BED},{'B',0x6BAE},{'C',0x3923},{'D',0x6B6E},
            {'E',0x79E7},{'F',0x79E4},{'G',0x396B},{'H',0x5BED},{'I',0x7497},
            {'J',0x126A},{'K',0x5BAD},{'L',0x4927},{'M',0x5F6D},{'N',0x6B6B},
            {'O',0x7B6F},{'P',0x7BE4},{'Q',0x7B79},{'R',0x7BF5},{'S',0x79CF},
            {'T',0x7492},{'U',0x5B6F},{'V',0x5B6A},{'W',0x5B7D},{'X',0x5AAD},
            {'Y',0x5A92},{'Z',0x72A7},{'+',0x05D0},{'-',0x01C0},{':',0x0410},
            {'.',0x0002},{',',0x0014},
        };
        uint16_t bits=0;
        char uc=(ch>='a'&&ch<='z')?(ch-32):ch;
        for(auto& g:glyphs) if(g.first==uc){bits=g.second;break;}
        SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);
        for(int row=0;row<5;++row)
            for(int col=0;col<3;++col)
                if(bits&(1<<(14-row*3-col)))
                    SDL_RenderDrawPoint(r,x+col,y+row);
    }

    static void drawText(SDL_Renderer* r, const std::string& s, int x,int y, SDL_Color c) {
        int cx=x;
        for(char ch:s){ drawChar(r,ch,cx,y,c); cx+=4; }
    }

    // ── binding rendering ─────────────────────────────────────────────────────
    void drawBinding(SDL_Renderer* r, int idx, bool selBinding) {
        const KeyBinding& b=profile_.bindings[idx];
        if (b.type==BindingType::DPad) { drawDPadBinding(r, idx, selBinding); return; }

        auto m=meta(b.type);
        int cx=toSX(b.center.x), cy=toSY(b.center.y);
        int rad=selBinding?16:12;

        SDL_Color col=m.color;
        if(!b.enabled){col.r/=2;col.g/=2;col.b/=2;}
        drawCircle(r,cx,cy,rad,col,true);
        drawCircle(r,cx,cy,rad,{255,255,255,200},false);
        if(selBinding) drawCircle(r,cx,cy,rad+4,{255,255,100,255},false);

        // Label above circle
        std::string lbl = b.label.empty() ? m.name : b.label;
        drawText(r,lbl,cx-((int)lbl.size()*4/2),cy-rad-8,{230,230,230,255});

        // Key hint below circle
        std::string hint;
        if(b.key!=SDLK_UNKNOWN){
            const char* kn=SDL_GetKeyName(b.key);
            hint=kn?kn:"?";
        } else if(b.mouseButton==SDL_BUTTON_LEFT) hint="LMB";
        else if(b.mouseButton==SDL_BUTTON_RIGHT)  hint="RMB";
        if(!hint.empty())
            drawText(r,hint,cx-((int)hint.size()*4/2),cy+rad+4,{160,200,255,255});

        // Swipe: arrow from center to swipeTo
        if(b.type==BindingType::Swipe){
            int sx2=toSX(b.swipeTo.x), sy2=toSY(b.swipeTo.y);
            SDL_SetRenderDrawColor(r,0,210,200,200);
            SDL_RenderDrawLine(r,cx,cy,sx2,sy2);
            drawCircle(r,sx2,sy2,6,{0,210,200,200},false);
        }
        // AimPan: clamp radius ring
        if(b.type==BindingType::AimPan||b.type==BindingType::AimAndShoot){
            int cr=(int)(b.aimClampRadius*vw_);
            drawCircle(r,cx,cy,cr,{255,180,60,80},false);
        }
    }

    // DPad: 4 fully independent points, each its own position + key. No
    // shared center, no fixed-pixel decoration - what you see here is
    // exactly what TouchInjector will touch (same toSX/toSY mapping as
    // every other binding), so it scales with the video and the window
    // exactly the way every other point already did.
    void drawDPadBinding(SDL_Renderer* r, int idx, bool selBinding) {
        static const char* kDirLabel[kDPadDirCount] = {"UP","DN","LT","RT"};
        const KeyBinding& b=profile_.bindings[idx];
        auto m=meta(BindingType::DPad);
        for (int d=0; d<kDPadDirCount; ++d) {
            const DPadPoint& dp=b.dpad[d];
            int cx=toSX(dp.point.x), cy=toSY(dp.point.y);
            bool thisSel = selBinding && selectedDpadDir_==d;
            int rad = thisSel?15:11;

            SDL_Color col=m.color;
            if(!dp.enabled){col.r/=2;col.g/=2;col.b/=2;}
            drawCircle(r,cx,cy,rad,col,true);
            drawCircle(r,cx,cy,rad,{255,255,255,200},false);
            if(thisSel) drawCircle(r,cx,cy,rad+4,{255,255,100,255},false);

            drawText(r,kDirLabel[d],cx-4,cy-rad-8,{230,230,230,255});

            std::string hint;
            if(dp.key!=SDLK_UNKNOWN){
                const char* kn=SDL_GetKeyName(dp.key);
                hint=kn?kn:"?";
            }
            if(!hint.empty())
                drawText(r,hint,cx-((int)hint.size()*4/2),cy+rad+4,{160,200,255,255});
        }
    }

    // ── bottom toolbar ────────────────────────────────────────────────────────
    void drawToolbar(SDL_Renderer* r, int idx) {
        KeyBinding& b=profile_.bindings[idx];
        bool isDpadPoint = (b.type==BindingType::DPad && selectedDpadDir_>=0);
        static const char* kDirLabel[kDPadDirCount] = {"UP","DN","LT","RT"};

        int bh=36, by=vy_+vh_-bh-4;
        drawRect(r,vx_,by,vw_,bh,{20,22,28,220});

        int x=vx_+8;
        // [Delete] - removes the whole binding (all 4 DPad points included).
        drawRect(r,x,by+6,52,24,{140,40,40,255});
        drawText(r,"DELETE",x+4,by+13,{255,200,200,255});
        deleteBtn_={x,by+6,52,24}; x+=60;

        // [Type] - label shows which direction when a DPad point is selected.
        auto m=meta(b.type);
        std::string typeLabel = isDpadPoint
            ? (std::string(m.name)+":"+kDirLabel[selectedDpadDir_]) : m.name;
        int tw=std::max(80,(int)typeLabel.size()*4+16);
        drawRect(r,x,by+6,tw,24,{40,44,52,255});
        drawOutlineRect(r,x,by+6,tw,24,m.color);
        drawText(r,typeLabel,x+4,by+13,m.color);
        typeBtn_={x,by+6,tw,24}; x+=tw+8;

        // [Key: xxx] - targets the selected DPad direction's own key when
        // one is selected, otherwise the binding's own key/mouse button.
        SDL_Keycode curKey    = isDpadPoint ? b.dpad[selectedDpadDir_].key : b.key;
        int         curMouse  = isDpadPoint ? 0 : b.mouseButton;
        std::string kl = waitKey_ ? "PRESS KEY..." :
                         (curKey!=SDLK_UNKNOWN ? ("KEY:"+std::string(SDL_GetKeyName(curKey))) :
                          curMouse==SDL_BUTTON_LEFT  ? "KEY:LMB" :
                          curMouse==SDL_BUTTON_RIGHT ? "KEY:RMB" : "SET KEY");
        int kw=std::max(80,(int)kl.size()*4+16);
        SDL_Color kc=waitKey_?SDL_Color{255,220,60,255}:SDL_Color{200,210,220,255};
        drawRect(r,x,by+6,kw,24,{40,44,52,255});
        drawOutlineRect(r,x,by+6,kw,24,kc);
        drawText(r,kl,x+4,by+13,kc);
        keyBtn_={x,by+6,kw,24}; x+=kw+8;

        // Sensitivity (aim types only)
        sensBtn_={0,0,0,0};
        if(b.type==BindingType::AimPan||b.type==BindingType::AimAndShoot){
            char sb[32]; std::snprintf(sb,sizeof(sb),"SENS:%.1f",b.aimSensitivity);
            drawRect(r,x,by+6,72,24,{40,44,52,255});
            drawText(r,sb,x+4,by+13,{200,200,200,255});
            drawText(r,"+",x+58,by+6,{200,200,200,255});
            drawText(r,"-",x+58,by+16,{200,200,200,255});
            sensBtn_={x,by+6,72,24}; x+=80;
        }

        // [Done]
        drawRect(r,vx_+vw_-68,by+6,60,24,{40,90,50,255});
        drawText(r,"DONE",vx_+vw_-56,by+13,{180,255,190,255});
        doneBtn_={vx_+vw_-68,by+6,60,24};
    }

    // ── add-mode picker ───────────────────────────────────────────────────────
    static constexpr BindingType kAllTypes[]={
        BindingType::TapPoint, BindingType::DPad, BindingType::AimPan,
        BindingType::ShootButton, BindingType::AimAndShoot,
        BindingType::HoldButton, BindingType::Swipe
    };
    static constexpr int kTypeCount=7;
    mutable SDL_Rect typePickerRects_[kTypeCount]{};

    void drawAddPicker(SDL_Renderer* r) {
        int pw=160, ph=kTypeCount*28+12;
        int px=vx_+vw_/2-pw/2, py=vy_+vh_/2-ph/2;
        drawRect(r,px,py,pw,ph,{28,30,38,240});
        drawOutlineRect(r,px,py,pw,ph,{100,105,115,255});
        drawText(r,"ADD BINDING",px+8,py+4,{200,210,220,255});
        for(int i=0;i<kTypeCount;++i){
            auto m=meta(kAllTypes[i]);
            int ry=py+14+i*28;
            bool sel=(kAllTypes[i]==addType_);
            drawRect(r,px+4,ry,pw-8,24,sel?SDL_Color{50,55,65,255}:SDL_Color{36,38,46,255});
            if(sel) drawOutlineRect(r,px+4,ry,pw-8,24,m.color);
            drawText(r,m.name,px+12,ry+8,m.color);
            typePickerRects_[i]={px+4,ry,pw-8,24};
        }
    }

    // ── toolbar hit-test rects (set during drawToolbar) ───────────────────────
    mutable SDL_Rect deleteBtn_{0,0,0,0};
    mutable SDL_Rect typeBtn_  {0,0,0,0};
    mutable SDL_Rect keyBtn_   {0,0,0,0};
    mutable SDL_Rect sensBtn_  {0,0,0,0};
    mutable SDL_Rect doneBtn_  {0,0,0,0};
    int addClickX_=0, addClickY_=0;

    static bool inRect(const SDL_Rect& rc,int x,int y){
        return x>=rc.x&&x<rc.x+rc.w&&y>=rc.y&&y<rc.y+rc.h;
    }

    // Lay out the 4 DPad points around (cx,cy) with sensible WASD defaults -
    // used both for a brand new DPad binding and when cycling a binding's
    // type *into* DPad, so it starts somewhere sane rather than collapsed.
    static void layoutDefaultDPad(KeyBinding& b, float cx, float cy, float radius=0.08f) {
        b.dpad[(int)DPadDir::Up]   ={{cx, std::clamp(cy-radius,0.f,1.f)}, SDLK_w, true};
        b.dpad[(int)DPadDir::Down] ={{cx, std::clamp(cy+radius,0.f,1.f)}, SDLK_s, true};
        b.dpad[(int)DPadDir::Left] ={{std::clamp(cx-radius,0.f,1.f), cy}, SDLK_a, true};
        b.dpad[(int)DPadDir::Right]={{std::clamp(cx+radius,0.f,1.f), cy}, SDLK_d, true};
    }

    // Switches a binding's type, handling the DPad <-> single-point
    // transition sensibly instead of just discarding position data:
    // leaving DPad reuses whichever point was selected as the new single
    // center; entering DPad lays out 4 points around the old center.
    void changeType(int idx, BindingType newType) {
        KeyBinding& b = profile_.bindings[idx];
        if (b.type==newType) return;
        if (b.type==BindingType::DPad && newType!=BindingType::DPad) {
            int dir = selectedDpadDir_>=0 ? selectedDpadDir_ : (int)DPadDir::Up;
            b.center = b.dpad[dir].point;
            b.key    = b.dpad[dir].key;
            selectedDpadDir_=-1;
        } else if (b.type!=BindingType::DPad && newType==BindingType::DPad) {
            layoutDefaultDPad(b, b.center.x, b.center.y);
            selectedDpadDir_=(int)DPadDir::Up;
        }
        b.type = newType;
    }

    // ── event handlers ────────────────────────────────────────────────────────
    bool onKeyDown(SDL_Keycode k) {
        if(waitKey_ && selected_>=0){
            if(k==SDLK_ESCAPE){ waitKey_=false; return true; }
            KeyBinding& b=profile_.bindings[selected_];
            if(b.type==BindingType::DPad && selectedDpadDir_>=0){
                b.dpad[selectedDpadDir_].key=k;
            } else {
                b.key=k;
                b.mouseButton=0;
            }
            waitKey_=false;
            return true;
        }
        if(k==SDLK_ESCAPE||k==SDLK_RETURN){ close(); return true; }
        if(k==SDLK_DELETE&&selected_>=0){
            profile_.bindings.erase(profile_.bindings.begin()+selected_);
            selected_=-1; selectedDpadDir_=-1; return true;
        }
        return true; // swallow all keys while editor open
    }

    bool onLMBDown(int mx,int my){
        waitKey_=false;

        // Add-mode picker click
        if(addMode_){
            for(int i=0;i<kTypeCount;++i){
                if(inRect(typePickerRects_[i],mx,my)){
                    addType_=kAllTypes[i];
                    // Place new binding at the saved click position.
                    KeyBinding nb;
                    nb.type=addType_;
                    nb.center.x=toNX(addClickX_);
                    nb.center.y=toNY(addClickY_);
                    nb.label=meta(addType_).name;
                    // For Swipe, default destination 5% below center.
                    if(addType_==BindingType::Swipe){
                        nb.swipeTo.x=nb.center.x;
                        nb.swipeTo.y=std::clamp(nb.center.y+0.05f,0.f,1.f);
                    }
                    if(addType_==BindingType::DPad){
                        layoutDefaultDPad(nb, nb.center.x, nb.center.y);
                    }
                    profile_.bindings.push_back(nb);
                    selected_=(int)profile_.bindings.size()-1;
                    selectedDpadDir_=(addType_==BindingType::DPad)?(int)DPadDir::Up:-1;
                    addMode_=false;
                    return true;
                }
            }
            addMode_=false; return true;
        }

        // Toolbar buttons
        if(selected_>=0){
            if(inRect(doneBtn_,mx,my))  { close(); return true; }
            if(inRect(deleteBtn_,mx,my)){
                profile_.bindings.erase(profile_.bindings.begin()+selected_);
                selected_=-1; selectedDpadDir_=-1; return true;
            }
            if(inRect(keyBtn_,mx,my))   { waitKey_=true; return true; }
            if(inRect(typeBtn_,mx,my)){
                // Cycle through types.
                for(int i=0;i<kTypeCount;++i)
                    if(kAllTypes[i]==profile_.bindings[selected_].type){
                        changeType(selected_, kAllTypes[(i+1)%kTypeCount]);
                        break;
                    }
                return true;
            }
            if(inRect(sensBtn_,mx,my)){
                // Upper half = +, lower half = -
                bool upper=(my < sensBtn_.y+sensBtn_.h/2);
                auto& b=profile_.bindings[selected_];
                b.aimSensitivity=std::clamp(b.aimSensitivity+(upper?0.1f:-0.1f),0.1f,5.f);
                return true;
            }
        }

        // Hit-test existing binding circles - DPad bindings expose 4
        // independent points instead of one.
        for(int i=0;i<(int)profile_.bindings.size();++i){
            const auto& b=profile_.bindings[i];
            if(b.type==BindingType::DPad){
                for(int d=0;d<kDPadDirCount;++d){
                    int cx=toSX(b.dpad[d].point.x), cy=toSY(b.dpad[d].point.y);
                    int dx=mx-cx, dy=my-cy;
                    if(dx*dx+dy*dy<=15*15){
                        selected_=i; selectedDpadDir_=d;
                        dragging_=true; dragOffX_=dx; dragOffY_=dy;
                        return true;
                    }
                }
                continue;
            }
            int cx=toSX(b.center.x), cy=toSY(b.center.y);
            int dx=mx-cx, dy=my-cy;
            if(dx*dx+dy*dy<=16*16){
                selected_=i; selectedDpadDir_=-1;
                dragging_=true;
                dragOffX_=dx; dragOffY_=dy;
                return true;
            }
        }

        // Empty video area click → open add picker.
        if(mx>=vx_&&mx<vx_+vw_&&my>=vy_&&my<vy_+vh_){
            addClickX_=mx; addClickY_=my;
            addMode_=true; selected_=-1; selectedDpadDir_=-1;
            return true;
        }
        return false;
    }

    bool onLMBUp(int /*mx*/,int /*my*/){
        dragging_=false;
        return false;
    }

    bool onMouseMove(int mx,int my){
        if(!dragging_||selected_<0) return false;
        auto& b=profile_.bindings[selected_];
        float nx=std::clamp(toNX(mx-dragOffX_),0.f,1.f);
        float ny=std::clamp(toNY(my-dragOffY_),0.f,1.f);
        if(b.type==BindingType::DPad && selectedDpadDir_>=0){
            b.dpad[selectedDpadDir_].point.x=nx;
            b.dpad[selectedDpadDir_].point.y=ny;
        } else {
            b.center.x=nx;
            b.center.y=ny;
        }
        return true;
    }
};
