#pragma once
// keymap_store.h — save / load KeyProfile as JSON in ./keymaps/<pkg>.json.
//
// Hand-rolled serialiser; the schema is flat so we don't need a library.
// JSON layout:
//   { "package":"…", "display":"…",
//     "bindings":[{ "type":"TapPoint","label":"Fire","key":119,
//                   "mouse_button":0,"cx":0.15,"cy":0.75,
//                   "sx":0,"sy":0,
//                   "du_x":0,"du_y":0,"du_key":0,"du_en":true,   (DPad only,
//                   "dd_x":0,"dd_y":0,"dd_key":0,"dd_en":true,    one block
//                   "dl_x":0,"dl_y":0,"dl_key":0,"dl_en":true,    per
//                   "dr_x":0,"dr_y":0,"dr_key":0,"dr_en":true,    direction)
//                   "aim_sens":1,"aim_clamp":0.15,
//                   "swipe_ms":150,"enabled":true }, …] }
//
// Old profiles saved before the DPad rework only have "cx"/"cy" and a
// (now-removed) "dpad_radius" for DPad bindings - load() below expands
// those into the 4 new points automatically the first time they're
// loaded, laid out the same way the old fixed-offset visualisation used
// to show them, so nobody's saved DPad position gets lost.

#include "keymap_types.h"

#include <filesystem>
#include <fstream>
#include <optional>
#include <string>
#include <vector>

namespace keymap_store {

namespace fs = std::filesystem;

inline fs::path profileDir()                        { return fs::path("keymaps"); }
inline fs::path profilePath(const std::string& pkg) { return profileDir()/(pkg+".json"); }

// ── tiny serialise helpers ────────────────────────────────────────────────────
inline std::string jStr(const std::string& s) {
    std::string o = "\"";
    for (char c : s) { if(c=='"') o+="\\\""; else if(c=='\\') o+="\\\\"; else o+=c; }
    return o + '"';
}
inline std::string jF(float v)  { char b[32]; std::snprintf(b,sizeof(b),"%.6g",v); return b; }

inline std::string typeToStr(BindingType t) {
    switch(t) {
        case BindingType::TapPoint:    return "TapPoint";
        case BindingType::DPad:        return "DPad";
        case BindingType::AimPan:      return "AimPan";
        case BindingType::ShootButton: return "ShootButton";
        case BindingType::AimAndShoot: return "AimAndShoot";
        case BindingType::HoldButton:  return "HoldButton";
        case BindingType::Swipe:       return "Swipe";
    }
    return "TapPoint";
}
inline BindingType strToType(const std::string& s) {
    if(s=="DPad")        return BindingType::DPad;
    if(s=="AimPan")      return BindingType::AimPan;
    if(s=="ShootButton") return BindingType::ShootButton;
    if(s=="AimAndShoot") return BindingType::AimAndShoot;
    if(s=="HoldButton")  return BindingType::HoldButton;
    if(s=="Swipe")       return BindingType::Swipe;
    return BindingType::TapPoint;
}

// ── tiny parse helpers ────────────────────────────────────────────────────────
inline std::string parseStr(const std::string& j, const std::string& k) {
    auto p=j.find('"'+k+'"'); if(p==std::string::npos) return {};
    auto c=j.find(':',p+k.size()+2); if(c==std::string::npos) return {};
    auto q1=j.find('"',c+1); if(q1==std::string::npos) return {};
    auto q2=j.find('"',q1+1); if(q2==std::string::npos) return {};
    return j.substr(q1+1,q2-q1-1);
}
inline bool hasKey(const std::string& j, const std::string& k) {
    return j.find('"'+k+'"') != std::string::npos;
}
inline double parseNum(const std::string& j, const std::string& k, double def=0) {
    auto p=j.find('"'+k+'"'); if(p==std::string::npos) return def;
    auto c=j.find(':',p+k.size()+2); if(c==std::string::npos) return def;
    size_t s=c+1; while(s<j.size()&&(j[s]==' '||j[s]=='\n')) ++s;
    try { return std::stod(j.substr(s)); } catch(...) { return def; }
}
inline bool parseBool(const std::string& j, const std::string& k, bool def=true) {
    auto p=j.find('"'+k+'"'); if(p==std::string::npos) return def;
    auto c=j.find(':',p+k.size()+2); if(c==std::string::npos) return def;
    size_t s=c+1; while(s<j.size()&&j[s]==' ') ++s;
    return (s+4<=j.size() && j.substr(s,4)=="true");
}

// ── save ─────────────────────────────────────────────────────────────────────
inline bool save(const KeyProfile& p) {
    std::error_code ec; fs::create_directories(profileDir(),ec);
    std::ofstream f(profilePath(p.packageName));
    if(!f) return false;
    f<<"{\n  \"package\":"<<jStr(p.packageName)<<",\n  \"display\":"
      <<jStr(p.displayName)<<",\n  \"bindings\":[\n";
    static const char* kPrefix[4] = {"du","dd","dl","dr"};  // Up,Down,Left,Right
    for(size_t i=0;i<p.bindings.size();++i){
        const auto& b=p.bindings[i];
        f<<"    {\n"
         <<"      \"type\":"        <<jStr(typeToStr(b.type))<<",\n"
         <<"      \"label\":"       <<jStr(b.label)<<",\n"
         <<"      \"key\":"         <<(int)b.key<<",\n"
         <<"      \"mouse_button\":"<<b.mouseButton<<",\n"
         <<"      \"cx\":"          <<jF(b.center.x)<<",\n"
         <<"      \"cy\":"          <<jF(b.center.y)<<",\n"
         <<"      \"sx\":"          <<jF(b.swipeTo.x)<<",\n"
         <<"      \"sy\":"          <<jF(b.swipeTo.y)<<",\n";
        for(int d=0; d<kDPadDirCount; ++d){
            const auto& dp=b.dpad[d];
            f<<"      \""<<kPrefix[d]<<"_x\":"  <<jF(dp.point.x)<<",\n"
             <<"      \""<<kPrefix[d]<<"_y\":"  <<jF(dp.point.y)<<",\n"
             <<"      \""<<kPrefix[d]<<"_key\":"<<(int)dp.key<<",\n"
             <<"      \""<<kPrefix[d]<<"_en\":" <<(dp.enabled?"true":"false")<<",\n";
        }
        f<<"      \"aim_sens\":"    <<jF(b.aimSensitivity)<<",\n"
         <<"      \"aim_clamp\":"   <<jF(b.aimClampRadius)<<",\n"
         <<"      \"swipe_ms\":"    <<b.swipeDurMs<<",\n"
         <<"      \"enabled\":"     <<(b.enabled?"true":"false")<<"\n"
         <<"    }"<<(i+1<p.bindings.size()?",":"")<<"\n";
    }
    f<<"  ]\n}\n";
    return f.good();
}

// ── load ─────────────────────────────────────────────────────────────────────
inline std::optional<KeyProfile> load(const std::string& packageName) {
    std::ifstream f(profilePath(packageName));
    if(!f) return std::nullopt;
    std::string j((std::istreambuf_iterator<char>(f)),{});

    KeyProfile pr;
    pr.packageName = parseStr(j,"package");
    pr.displayName = parseStr(j,"display");
    if(pr.packageName.empty()) pr.packageName=packageName;

    auto arr=j.find("\"bindings\""); if(arr==std::string::npos) return pr;
    auto brk=j.find('[',arr);       if(brk==std::string::npos) return pr;

    static const char* kPrefix[4] = {"du","dd","dl","dr"};
    size_t pos=brk+1;
    while(true){
        auto os=j.find('{',pos); if(os==std::string::npos) break;
        auto oe=j.find('}',os+1); if(oe==std::string::npos) break;
        std::string o=j.substr(os,oe-os+1);
        KeyBinding b;
        b.type          =strToType(parseStr(o,"type"));
        b.label         =parseStr(o,"label");
        b.key           =(SDL_Keycode)(int)parseNum(o,"key");
        b.mouseButton   =(int)parseNum(o,"mouse_button");
        b.center.x      =(float)parseNum(o,"cx",0.5);
        b.center.y      =(float)parseNum(o,"cy",0.5);
        b.swipeTo.x     =(float)parseNum(o,"sx");
        b.swipeTo.y     =(float)parseNum(o,"sy");

        if (b.type==BindingType::DPad) {
            if (hasKey(o,"du_x")) {
                // New-format profile: each direction has its own saved point/key.
                for (int d=0; d<kDPadDirCount; ++d) {
                    auto& dp=b.dpad[d];
                    std::string px=kPrefix[d]; 
                    dp.point.x = (float)parseNum(o,px+"_x",0.5);
                    dp.point.y = (float)parseNum(o,px+"_y",0.5);
                    dp.key     = (SDL_Keycode)(int)parseNum(o,px+"_key",SDLK_UNKNOWN);
                    dp.enabled = parseBool(o,px+"_en",true);
                }
            } else {
                // Old-format profile (pre-rework): a single center + radius,
                // with hardcoded WASD. Expand into 4 points at the same
                // visual offsets so the saved layout doesn't just vanish -
                // from here on each one drags/rebinds independently.
                float radius=(float)parseNum(o,"dpad_radius",0.08);
                b.dpad[(int)DPadDir::Up]   ={{b.center.x, b.center.y-radius}, SDLK_w, true};
                b.dpad[(int)DPadDir::Down] ={{b.center.x, b.center.y+radius}, SDLK_s, true};
                b.dpad[(int)DPadDir::Left] ={{b.center.x-radius, b.center.y}, SDLK_a, true};
                b.dpad[(int)DPadDir::Right]={{b.center.x+radius, b.center.y}, SDLK_d, true};
            }
        }

        b.aimSensitivity=(float)parseNum(o,"aim_sens",1.0);
        b.aimClampRadius=(float)parseNum(o,"aim_clamp",0.15);
        b.swipeDurMs    =(int)  parseNum(o,"swipe_ms",150);
        b.enabled       =parseBool(o,"enabled",true);
        pr.bindings.push_back(b);
        pos=oe+1;
    }
    return pr;
}

inline std::vector<std::string> listPackages() {
    std::vector<std::string> r;
    std::error_code ec;
    for(auto& e:fs::directory_iterator(profileDir(),ec))
        if(e.path().extension()==".json") r.push_back(e.path().stem().string());
    return r;
}

} // namespace keymap_store
