#pragma once
// Capturer: runs `adb exec-out screenrecord --output-format=h264 -` on a
// background thread, decodes the H264 stream with libavcodec, and pushes
// each decoded frame directly into a FrameBuffer slot via beginWrite /
// publishFrame — no intermediate copy.
//
// Changes from v1:
//   • Uses FrameBuffer::beginWrite / publishFrame (triple-buffer, zero copy)
//   • 256 KB fread buffer (down from 64 KB) — fewer syscalls, less jitter
//   • Reconnect delay reduced from 300 ms → 50 ms
//   • Decode thread boosted to high OS priority (platform-specific)

extern "C" {
#include <libavcodec/avcodec.h>
#include <libswscale/swscale.h>
#include <libavutil/imgutils.h>
}

#include <atomic>
#include <string>
#include <thread>

#include "frame_buffer.h"

class Capturer {
public:
    Capturer(FrameBuffer& frameBuffer, std::string serial,
             std::string bitrate, std::string size);
    ~Capturer();

    Capturer(const Capturer&) = delete;
    Capturer& operator=(const Capturer&) = delete;

    void start();
    void stop();

    bool isConnected() const { return connected_.load(); }
    const std::string& serial() const { return serial_; }

private:
    void threadMain();
    void runOneSession();
    void storeFrame(AVFrame* frame);

    FrameBuffer& frameBuffer_;
    std::string  serial_;
    std::string  bitrate_;
    std::string  size_;

    std::atomic<bool> running_{false};
    std::atomic<bool> connected_{false};
    std::thread       thread_;

    // swscale conversion cache — only used if the decoder hands us
    // something other than planar YUV420P (rare, but handle it).
    SwsContext* swsCtx_    = nullptr;
    int         swsSrcFmt_ = -1;
    int         swsW_      = 0;
    int         swsH_      = 0;
};
