#pragma once
// Panel: slide-out drawer with volume/power/screenshot/keymap buttons.
// Unchanged from base except:
//   • Button enum adds kKeymap
//   • keymapCallback_ invoked when Keymap button pressed (set by App)
//   • kPanelWidth widened slightly to fit 5th button comfortably

#include <SDL.h>

#include <atomic>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>

class Panel {
public:
    Panel();

    void setSerial(std::string serial) { serial_ = std::move(serial); }

    // App sets this so the Panel can open the KeymapEditor without
    // needing a direct pointer to it.
    void setKeymapCallback(std::function<void()> cb) { keymapCb_ = std::move(cb); }

    bool handleEvent(const SDL_Event& e, int windowW, int windowH);
    void update(uint32_t nowMs);
    void render(SDL_Renderer* renderer, int windowW, int windowH);

    void toggle();
    bool isOpen() const { return open_; }

    int extraWidth() const { return kTabWidth + static_cast<int>(offsetX_); }

private:
    enum class Button {
        kVolumeUp, kVolumeDown, kPower, kScreenshot, kKeymap, kCount
    };
    static constexpr int kButtonCount = static_cast<int>(Button::kCount);

    SDL_Rect tabRect(int windowH) const;
    SDL_Rect panelRect(int windowH) const;
    SDL_Rect buttonRect(int index, int windowH) const;
    int hitTestButton(int mouseX, int mouseY, int windowH) const;
    void activate(Button b);

    std::string serial_;
    std::function<void()> keymapCb_;

    bool     open_     = false;
    float    offsetX_  = 0.f;
    uint32_t lastUpdateMs_ = 0;

    int  hoveredButton_ = -1;
    int  pressedButton_ = -1;
    bool tabPressed_    = false;

    std::shared_ptr<std::atomic<uint32_t>> screenshotFlashUntilMs_ =
        std::make_shared<std::atomic<uint32_t>>(0);
    std::shared_ptr<std::atomic<bool>> screenshotFlashOk_ =
        std::make_shared<std::atomic<bool>>(true);

    // Keymap button flash (briefly highlights when editor opens).
    std::atomic<uint32_t> keymapFlashUntilMs_{0};

    static constexpr int kPanelWidth = 90;   // widened from 84 for 5 buttons
    static constexpr int kTabWidth   = 22;
    static constexpr int kTabHeight  = 80;
    static constexpr int kButtonSize = 52;
    static constexpr int kButtonGap  = 12;
    static constexpr float kSlideSpeed = 700.f;
};
