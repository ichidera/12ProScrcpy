#include "app.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <thread>

App::App() = default;
App::~App() {
    if (texture_)  SDL_DestroyTexture(texture_);
    if (renderer_) SDL_DestroyRenderer(renderer_);
    if (window_)   SDL_DestroyWindow(window_);
    SDL_Quit();
}

bool App::init() {
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        std::fprintf(stderr,"SDL_Init failed: %s\n",SDL_GetError()); return false;
    }
    window_=SDL_CreateWindow("adbmirror - waiting for device...",
        SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,
        420+panel_.extraWidth(),860,SDL_WINDOW_RESIZABLE|SDL_WINDOW_ALLOW_HIGHDPI);
    if(!window_){std::fprintf(stderr,"SDL_CreateWindow failed: %s\n",SDL_GetError());return false;}
    appliedExtraPx_=panel_.extraWidth();
    renderer_=SDL_CreateRenderer(window_,-1,SDL_RENDERER_ACCELERATED);
    if(!renderer_) renderer_=SDL_CreateRenderer(window_,-1,SDL_RENDERER_SOFTWARE);
    if(!renderer_){std::fprintf(stderr,"SDL_CreateRenderer failed: %s\n",SDL_GetError());return false;}
    SDL_SetHint(SDL_HINT_RENDER_VSYNC,"0");
    return true;
}

void App::computeVideoRect(int winW,int winH,bool fill,int& vx,int& vy,int& vw,int& vh) const {
    int panelPx=appliedExtraPx_;
    vx=panelPx; vw=winW-panelPx;
    if(texW_<=0||texH_<=0){vy=0;vh=winH;return;}
    float scale=fill
        ?std::max((float)vw/texW_,(float)winH/texH_)
        :std::min((float)vw/texW_,(float)winH/texH_);
    int drawW=(int)(texW_*scale), drawH=(int)(texH_*scale);
    vx=panelPx+(vw-drawW)/2; vy=(winH-drawH)/2; vw=drawW; vh=drawH;
}

void App::openKeymapEditor() {
    auto loaded=keymap_store::load(currentPackage_);
    KeyProfile profile=loaded.value_or(KeyProfile{currentPackage_,currentPackage_,{}});
    kmEditor_.open(profile,[this](const KeyProfile& saved){
        keymap_store::save(saved);
        kmController_.setProfile(saved);
        keymapActive_=!saved.bindings.empty();
        editorOpen_=false;
    });
    editorOpen_=true; keymapActive_=false;
}

void App::closeKeymapEditor() { kmEditor_.close(); }

void App::pollForegroundPackage() {
    std::string cmd=serial_.empty()
        ?"adb shell dumpsys window 2>/dev/null"
        :("adb -s "+serial_+" shell dumpsys window 2>/dev/null");
    FILE* p=popen(cmd.c_str(),"r"); if(!p) return;
    char line[512]; std::string pkg;
    while(std::fgets(line,sizeof(line),p)){
        char* tok=std::strstr(line,"mCurrentFocus=");
        if(!tok) tok=std::strstr(line,"mFocusedApp=");
        if(!tok) continue;
        char* slash=std::strchr(tok,'/'); if(!slash) continue;
        char* space=slash;
        while(space>tok&&*space!=' '&&*space!='{') --space;
        if(*space==' '||*space=='{') ++space;
        pkg=std::string(space,slash); break;
    }
    pclose(p);
    if(!pkg.empty()&&pkg!=currentPackage_){
        currentPackage_=pkg; applyProfile(pkg);
    }
}

void App::applyProfile(const std::string& pkg) {
    auto loaded=keymap_store::load(pkg);
    if(loaded&&!loaded->bindings.empty()){
        kmController_.setProfile(*loaded);
        keymapActive_=true;
    } else {
        kmController_.clearProfile();
        keymapActive_=false;
    }
}

void App::pollRotation() {
    // "SurfaceOrientation: N" in `dumpsys input`'s display-viewport dump -
    // N is 0/1/2/3 for 0/90/180/270°, same convention as Surface.ROTATION_*.
    // If parsing ever fails to find it (different Android build/OEM), we
    // simply keep whatever rotation we last knew about rather than
    // snapping back to 0 and re-breaking touch placement.
    std::string cmd=serial_.empty()
        ?"adb shell dumpsys input 2>/dev/null"
        :("adb -s "+serial_+" shell dumpsys input 2>/dev/null");
    FILE* p=popen(cmd.c_str(),"r"); if(!p) return;
    char line[512]; int rot=-1;
    while(std::fgets(line,sizeof(line),p)){
        char* tok=std::strstr(line,"SurfaceOrientation:");
        if(!tok) continue;
        tok+=std::strlen("SurfaceOrientation:");
        while(*tok==' ') ++tok;
        rot=std::atoi(tok);
        break;
    }
    pclose(p);
    if(rot>=0&&rot<=3&&rot!=currentRotation_){
        currentRotation_=rot;
        kmController_.setRotation(rot);
    }
}

void App::setCursorLocked(bool locked){
    cursorLocked_=locked;
    SDL_SetRelativeMouseMode(locked?SDL_TRUE:SDL_FALSE);
    if(locked){
        // Open the aim contact for any AimPan / AimAndShoot binding.
        // Locking cursor = placing the right-thumb contact on screen.
        // It stays alive until cursor unlocks (BlueStacks Shooting Mode model).
        if(keymapActive_){
            for(auto& b : kmController_.profile().bindings){
                if(!b.enabled) continue;
                if(b.type==BindingType::AimPan||b.type==BindingType::AimAndShoot){
                    kmController_.injector().aimOpen(b.center.x, b.center.y);
                    break;
                }
            }
        }
    } else {
        kmController_.releaseAll();
    }
}

void App::handleKeyDown(SDL_Keycode key){
    switch(key){
        case SDLK_F1: setCursorLocked(!cursorLocked_); break;
        case SDLK_F2: fillMode_=!fillMode_; break;
        case SDLK_F3: panel_.toggle(); break;
        case SDLK_F4:
            if(editorOpen_) closeKeymapEditor();
            else            openKeymapEditor();
            break;
        case SDLK_ESCAPE:
            if(editorOpen_)   {closeKeymapEditor();break;}
            if(cursorLocked_) {setCursorLocked(false);break;}
            running_=false; break;
        case SDLK_q: running_=false; break;
        default: break;
    }
}

void App::uploadFrame(const FrameBuffer::View& view){
    if(!texture_||view.width!=texW_||view.height!=texH_){
        if(texture_) SDL_DestroyTexture(texture_);
        texture_=SDL_CreateTexture(renderer_,SDL_PIXELFORMAT_IYUV,
            SDL_TEXTUREACCESS_STREAMING,view.width,view.height);
        texW_=view.width; texH_=view.height;
    }
    if(!texture_) return;
    void* pixels=nullptr; int pitch=0;
    if(SDL_LockTexture(texture_,nullptr,&pixels,&pitch)!=0){
        SDL_UpdateYUVTexture(texture_,nullptr,view.y,view.width,view.u,view.width/2,view.v,view.width/2);
        return;
    }
    uint8_t* dst=static_cast<uint8_t*>(pixels); int uPitch=pitch/2;
    for(int row=0;row<view.height;++row)
        std::memcpy(dst+row*pitch,view.y+row*view.width,(size_t)view.width);
    uint8_t* uDst=dst+pitch*view.height;
    for(int row=0;row<view.height/2;++row)
        std::memcpy(uDst+row*uPitch,view.u+row*(view.width/2),(size_t)(view.width/2));
    uint8_t* vDst=uDst+uPitch*(view.height/2);
    for(int row=0;row<view.height/2;++row)
        std::memcpy(vDst+row*uPitch,view.v+row*(view.width/2),(size_t)(view.width/2));
    SDL_UnlockTexture(texture_);
}

void App::renderFrame(){
    SDL_SetRenderDrawColor(renderer_,12,12,16,255);
    SDL_RenderClear(renderer_);
    if(texture_){
        int winW,winH; SDL_GetRendererOutputSize(renderer_,&winW,&winH);
        int vx,vy,vw,vh;
        computeVideoRect(winW,winH,editorOpen_?false:fillMode_,vx,vy,vw,vh);
        SDL_Rect dst{vx,vy,vw,vh};
        SDL_RenderCopy(renderer_,texture_,nullptr,&dst);
    }
}

void App::updateTitle(const Capturer& capturer,unsigned fps){
    char title[320];
    std::snprintf(title,sizeof(title),
        "adbmirror - %s - %u fps - cursor %s (F1) - %s (F2) - keymap %s (F4)",
        capturer.isConnected()?"connected":"waiting...",fps,
        cursorLocked_?"LOCKED":"free",fillMode_?"fill":"fit",
        editorOpen_?"EDITING":keymapActive_?"ON":"off");
    SDL_SetWindowTitle(window_,title);
}

int App::run(FrameBuffer& frameBuffer,const Capturer& capturer){
    serial_=capturer.serial();
    kmController_.reset(serial_);   // re-init serial without move-assigning mutexes
    panel_.setSerial(serial_);
    panel_.setKeymapCallback([this]{openKeymapEditor();});

    uint32_t lastTitleUpdate=SDL_GetTicks();
    unsigned framesSinceTitle=0;

    while(running_){
        int winW,winH;
        SDL_GetRendererOutputSize(renderer_,&winW,&winH);
        int vx,vy,vw,vh;
        computeVideoRect(winW,winH,editorOpen_?false:fillMode_,vx,vy,vw,vh);
        kmController_.setVideoRect(vx,vy,vw,vh);

        SDL_Event e;
        while(SDL_PollEvent(&e)){
            if(editorOpen_&&kmEditor_.handleEvent(e,vx,vy,vw,vh)) continue;
            if(panel_.handleEvent(e,winW,winH)) continue;
            if(cursorLocked_&&!editorOpen_&&kmController_.handleEvent(e,keymapActive_)) continue;
            if(e.type==SDL_QUIT){running_=false;}
            else if(e.type==SDL_KEYDOWN&&!e.key.repeat) handleKeyDown(e.key.keysym.sym);
        }

        FrameBuffer::View view=frameBuffer.consume();
        if(view.valid){uploadFrame(view);++framesSinceTitle;}

        uint32_t now=SDL_GetTicks();
        panel_.update(now);

        int desiredExtraPx=panel_.extraWidth();
        // The device rotated (portrait<->landscape, or any other aspect
        // change) - resize the window's video area to match the new shape
        // *before* applying it below, the same way scrcpy follows device
        // orientation. Otherwise "fill" mode keeps covering the window at
        // the old aspect and crops away most of the new frame, and "fit"
        // mode leaves huge unexplained letterbox bars - either way the
        // window stops matching what's actually on the phone.
        bool aspectChanged = prevTexW_>0 && prevTexH_>0 && texW_>0 && texH_>0 &&
            std::abs((float)texW_/texH_ - (float)prevTexW_/prevTexH_) > 0.05f;
        prevTexW_=texW_; prevTexH_=texH_;

        int videoAreaPx=winW-appliedExtraPx_;
        if(aspectChanged){
            // Keep the current window height, re-derive the video-area
            // width that makes the new frame exactly fill it - zero crop,
            // zero letterbox, regardless of which fill mode is active.
            videoAreaPx=std::max(200,(int)std::lround(winH*((double)texW_/texH_)));
        }
        if(desiredExtraPx!=appliedExtraPx_ || aspectChanged){
            appliedExtraPx_=desiredExtraPx;
            int newTotalPx=videoAreaPx+appliedExtraPx_;
            int winPts,hPts; SDL_GetWindowSize(window_,&winPts,&hPts);
            float dpiScale=winW>0?(float)winPts/winW:1.f;
            SDL_SetWindowSize(window_,(int)(newTotalPx*dpiScale+0.5f),hPts);
            winW=newTotalPx;
        }

        renderFrame();
        if(editorOpen_) kmEditor_.render(renderer_,vx,vy,vw,vh);
        panel_.render(renderer_,winW,winH);
        SDL_RenderPresent(renderer_);

        if(!view.valid) SDL_Delay(1);

        if(now-lastTitleUpdate>=1000){
            updateTitle(capturer,framesSinceTitle);
            framesSinceTitle=0; lastTitleUpdate=now;
        }

        if(!editorOpen_&&now-lastPackagePollMs_>=2000){
            lastPackagePollMs_=now;
            std::thread([this]{pollForegroundPackage();}).detach();
        }
        if(now-lastRotationPollMs_>=1000){
            lastRotationPollMs_=now;
            std::thread([this]{pollRotation();}).detach();
        }
    }
    return 0;
}
