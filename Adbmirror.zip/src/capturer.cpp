#include "capturer.h"

#include <chrono>
#include <cstdio>
#include <vector>

#ifdef _WIN32
#  include <fcntl.h>
#  include <io.h>
#  include <windows.h>
#  define POPEN  _popen
#  define PCLOSE _pclose
#else
#  include <pthread.h>
#  include <sched.h>
#  include <unistd.h>  // ::nice()
#  define POPEN  popen
#  define PCLOSE pclose
#endif

// 256 KB read buffer.  Larger reads → fewer fread()/kernel round-trips
// → less per-frame jitter.  Old value was 64 KB.
static constexpr size_t kReadBufBytes = 256 * 1024;

// After screenrecord hits its ~180 s limit (or the device disconnects),
// wait this long before restarting.  50 ms is fast enough to feel seamless
// in a game; old value was 300 ms.
static constexpr int kReconnectDelayMs = 50;

static void boostThreadPriority() {
#ifdef _WIN32
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
#else
    // Try SCHED_FIFO (real-time).  Falls back silently if we lack
    // CAP_SYS_NICE — non-root users get the nice value instead.
    sched_param sp{};
    sp.sched_priority = sched_get_priority_max(SCHED_FIFO);
    if (pthread_setschedparam(pthread_self(), SCHED_FIFO, &sp) != 0) {
        // Fall back: raise nice value as much as the OS allows.
        // nice(-20) may return EPERM; that's fine, the return value is
        // deliberately unused - there's nothing more corrective to do.
        int rc = ::nice(-20);
        (void)rc;
    }
#endif
}

Capturer::Capturer(FrameBuffer& frameBuffer, std::string serial,
                   std::string bitrate, std::string size)
    : frameBuffer_(frameBuffer),
      serial_(std::move(serial)),
      bitrate_(std::move(bitrate)),
      size_(std::move(size)) {}

Capturer::~Capturer() {
    stop();
    if (swsCtx_) sws_freeContext(swsCtx_);
}

void Capturer::start() {
    if (running_.exchange(true)) return;
    thread_ = std::thread(&Capturer::threadMain, this);
}

void Capturer::stop() {
    if (!running_.exchange(false)) return;
    if (thread_.joinable()) thread_.join();
}

void Capturer::threadMain() {
    boostThreadPriority();
    while (running_.load()) {
        runOneSession();
        connected_.store(false);
        std::this_thread::sleep_for(std::chrono::milliseconds(kReconnectDelayMs));
    }
}

void Capturer::storeFrame(AVFrame* f) {
    int w = f->width  & ~1;
    int h = f->height & ~1;
    if (w <= 0 || h <= 0) return;

    // If the decoder gives us something other than planar YUV420P,
    // convert first using swscale — same as before.
    AVFrame* converted = nullptr;
    const uint8_t* srcData[4]  = {f->data[0], f->data[1], f->data[2], f->data[3]};
    int            srcLs[4]    = {f->linesize[0], f->linesize[1],
                                   f->linesize[2], f->linesize[3]};

    if (f->format != AV_PIX_FMT_YUV420P) {
        if (!swsCtx_ || swsSrcFmt_ != f->format || swsW_ != w || swsH_ != h) {
            if (swsCtx_) sws_freeContext(swsCtx_);
            swsCtx_ = sws_getContext(w, h, (AVPixelFormat)f->format,
                                     w, h, AV_PIX_FMT_YUV420P,
                                     SWS_FAST_BILINEAR,
                                     nullptr, nullptr, nullptr);
            swsSrcFmt_ = f->format;
            swsW_ = w;
            swsH_ = h;
        }
        if (!swsCtx_) return;

        converted = av_frame_alloc();
        converted->format = AV_PIX_FMT_YUV420P;
        converted->width  = w;
        converted->height = h;
        if (av_frame_get_buffer(converted, 32) < 0) {
            av_frame_free(&converted);
            return;
        }
        sws_scale(swsCtx_, f->data, f->linesize, 0, h,
                  converted->data, converted->linesize);
        for (int i = 0; i < 4; ++i) {
            srcData[i] = converted->data[i];
            srcLs[i]   = converted->linesize[i];
        }
    }

    // --- Zero-copy path into the triple buffer ---
    // beginWrite() hands us pointers to the slot's pixel vectors,
    // pre-sized to w*h and (w/2)*(h/2).  We write directly into them
    // with av_image_copy, no temporary vectors at all.
    uint8_t* yDst = nullptr;
    uint8_t* uDst = nullptr;
    uint8_t* vDst = nullptr;
    frameBuffer_.beginWrite(w, h, &yDst, &uDst, &vDst);

    uint8_t* dstData[4]  = {yDst, uDst, vDst, nullptr};
    int      dstLs[4]    = {w, w / 2, w / 2, 0};
    av_image_copy(dstData, dstLs, srcData, srcLs, AV_PIX_FMT_YUV420P, w, h);

    frameBuffer_.publishFrame();

    if (converted) av_frame_free(&converted);
}

void Capturer::runOneSession() {
    std::string cmd = "adb ";
    if (!serial_.empty()) cmd += "-s " + serial_ + " ";
    cmd += "exec-out screenrecord --output-format=h264 --bit-rate " + bitrate_;
    if (!size_.empty()) cmd += " --size " + size_;
    cmd += " -";

    FILE* pipe = POPEN(cmd.c_str(), "rb");
    if (!pipe) return;
#ifdef _WIN32
    _setmode(_fileno(pipe), _O_BINARY);
#endif

    const AVCodec*         codec  = avcodec_find_decoder(AV_CODEC_ID_H264);
    AVCodecParserContext*  parser = nullptr;
    AVCodecContext*        ctx    = nullptr;

    if (!codec) {
        std::fprintf(stderr, "No H264 decoder available\n");
        PCLOSE(pipe);
        return;
    }
    parser = av_parser_init(codec->id);
    ctx    = avcodec_alloc_context3(codec);
    if (!parser || !ctx || avcodec_open2(ctx, codec, nullptr) < 0) {
        std::fprintf(stderr, "Failed to init H264 decoder\n");
        if (parser) av_parser_close(parser);
        if (ctx)    avcodec_free_context(&ctx);
        PCLOSE(pipe);
        return;
    }

    // Enable low-delay mode in the decoder — don't buffer multiple
    // frames waiting for B-frame reordering.  screenrecord doesn't
    // emit B-frames, but setting this flag makes the decoder flush
    // each frame the moment it's decoded rather than accumulating them.
    ctx->flags |= AV_CODEC_FLAG_LOW_DELAY;
    ctx->flags2 |= AV_CODEC_FLAG2_FAST;

    AVPacket* pkt   = av_packet_alloc();
    AVFrame*  frame = av_frame_alloc();

    std::vector<uint8_t> inbuf(kReadBufBytes);
    size_t n;
    while (running_.load() &&
           (n = std::fread(inbuf.data(), 1, inbuf.size(), pipe)) > 0) {
        const uint8_t* data     = inbuf.data();
        size_t         dataSize = n;

        while (dataSize > 0) {
            int used = av_parser_parse2(parser, ctx,
                                        &pkt->data, &pkt->size,
                                        data, (int)dataSize,
                                        AV_NOPTS_VALUE, AV_NOPTS_VALUE, 0);
            if (used < 0) break;
            data     += used;
            dataSize -= (size_t)used;

            if (pkt->size) {
                if (avcodec_send_packet(ctx, pkt) == 0) {
                    while (avcodec_receive_frame(ctx, frame) == 0) {
                        connected_.store(true);
                        storeFrame(frame);
                    }
                }
            }
        }
    }

    // Flush buffered frames.
    avcodec_send_packet(ctx, nullptr);
    while (avcodec_receive_frame(ctx, frame) == 0) storeFrame(frame);

    av_frame_free(&frame);
    av_packet_free(&pkt);
    av_parser_close(parser);
    avcodec_free_context(&ctx);
    PCLOSE(pipe);
}
