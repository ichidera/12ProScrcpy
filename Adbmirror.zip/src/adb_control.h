#pragma once
// adb_control: hardware-button injection and a screenshot pull for one
// specific rooted device (Qualcomm Waipio-class board, see
// docs/real-device-adb-sendevent.md for the full writeup of why).
//
// This is NOT the generic `adb shell input keyevent` path - that's
// exactly what didn't work here. This device's SELinux policy blocks
// key injection through the normal input-injection path, so root +
// `setenforce 0` + raw `sendevent` straight into the PMIC/gpio-keys
// device nodes is required, matching the sequences verified in that
// doc. Every call spawns its own detached thread so the render loop
// never blocks on an adb round-trip (each button press is 5 sequential
// adb invocations - setenforce, then a down/up pair each followed by a
// SYN_REPORT - so it can take on the order of a second).
//
// If this app is ever pointed at a different device, the three
// device-node/keycode constants at the top of adb_control.cpp are the
// only things that need to change (find them the same way the doc
// does: `adb shell su -c "cat /proc/bus/input/devices"` and
// `ls -la /dev/input/`).

#include <functional>
#include <string>

namespace adbctl {

void volumeUp(const std::string& serial);
void volumeDown(const std::string& serial);
void powerButton(const std::string& serial);

// Pulls a PNG screenshot via `adb exec-out screencap -p` into the
// current working directory, named adbmirror-YYYYMMDD-HHMMSS.png.
// `onDone` fires from the background thread once the command exits -
// it only carries plain data (bool + path), so it's safe to hop back
// onto the render thread before touching any SDL state from it.
void screenshot(const std::string& serial,
                 std::function<void(bool ok, std::string path)> onDone);

}  // namespace adbctl
