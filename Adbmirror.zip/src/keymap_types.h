#pragma once
// keymap_types.h — data model for the keymap / keybinding system.
//
// All positions stored as normalised floats [0..1] relative to the *video
// rectangle* rendered by App::renderFrame().  Resolution-independent, panel-
// width-independent.  Conversion to device touch-space (0–14399 × 0–31999,
// per docs/real-device-adb-sendevent.md §1 §4) happens inside TouchInjector.
//
// Binding types are modelled on BlueStacks' keymapping UI, translated to
// the real Type-B multitouch protocol the fts driver expects.

#include <SDL.h>
#include <array>
#include <string>
#include <vector>

// ─── BindingType ────────────────────────────────────────────────────────────

enum class BindingType {
    // Key/mouse-button → short tap at a fixed point.
    // Good for: skill buttons, jump, interact, loot.
    TapPoint,

    // 4 independent buttons - up/down/left/right - each its own screen
    // position and its own key, each just a held touch (same mechanism
    // as HoldButton). Any combination can be held together for diagonals.
    // Not a virtual joystick with one moving contact: each direction is
    // its own separate, freely-placeable, freely-bindable button, so it
    // scales/repositions exactly like every other binding type.
    // Good for: movement buttons in TPS / MOBA.
    DPad,

    // Mouse movement → continuous finger drag around an anchor.
    // Mouse Δpx → aimSensitivity × Δ (normalised), clamped to aimClampRadius.
    // Requires cursor lock (F1).
    // Good for: camera / right-stick aiming.
    AimPan,

    // Mouse left-click → tap at a fixed fire point.
    // Naturally pairs with AimPan (different slots → simultaneous touches).
    // Good for: fire / attack button.
    ShootButton,

    // AimPan + ShootButton combined.
    // Mouse move = aim drag.  Left-click = shoot while aim contact held.
    // This is BlueStacks' "Shooting Mode" button.
    AimAndShoot,

    // Key held → touch-down sustained; key released → touch-up.
    // Periodic micro-jitter keeps the contact alive (doc §8 note on stuck sensors).
    // Good for: ADS / scope hold, charge abilities.
    HoldButton,

    // Key press → interpolated swipe from center → swipeTo over swipeDurMs.
    // Good for: quick-loot drag, scroll, slide-to-dodge.
    Swipe,
};

// ─── BindingPoint ────────────────────────────────────────────────────────────

struct BindingPoint {
    float x = 0.5f;   // [0..1] within video rect width
    float y = 0.5f;   // [0..1] within video rect height
};

// ─── DPadDir / DPadPoint ─────────────────────────────────────────────────────

// Index into KeyBinding::dpad[]. Fixed order, also used directly as the
// TouchInjector slot number (see TouchInjector::kSlotDPadUp etc) so each
// direction is always its own stable multitouch contact.
enum class DPadDir { Up = 0, Down = 1, Left = 2, Right = 3 };
constexpr int kDPadDirCount = 4;

struct DPadPoint {
    BindingPoint point;               // its own position, independent of the others
    SDL_Keycode  key = SDLK_UNKNOWN;  // its own trigger key, independent of the others
    bool         enabled = true;      // false = configured but inactive (key kept, ignored)
};

// ─── KeyBinding ──────────────────────────────────────────────────────────────

struct KeyBinding {
    // --- what it does ---
    BindingType  type  = BindingType::TapPoint;
    std::string  label;              // overlay label ("Fire", "Move", …)

    // --- trigger ---
    // Keyboard-driven (TapPoint, HoldButton, Swipe):
    //   key = SDL keycode,  mouseButton = 0
    // Mouse-driven (AimPan, ShootButton, AimAndShoot):
    //   key = SDLK_UNKNOWN, mouseButton = SDL_BUTTON_LEFT / RIGHT / MIDDLE
    // DPad ignores this pair entirely - see dpad[] below.
    SDL_Keycode  key         = SDLK_UNKNOWN;
    int          mouseButton = 0;

    // --- position ---
    BindingPoint center;     // anchor for all types except DPad
    BindingPoint swipeTo;    // Swipe destination (other types ignore this)

    // DPad only: 4 independent points (see DPadDir). Everything else
    // ignores this. Defaults (on creation) are laid out around wherever
    // the user clicked; from then on each one drags and rebinds on its
    // own, same as any other binding's point.
    std::array<DPadPoint, kDPadDirCount> dpad;

    // --- per-type tuning ---
    float aimSensitivity = 1.0f;   // AimPan: mouse-px → norm-delta multiplier (/1000)
    float aimClampRadius = 0.15f;  // AimPan: max wander from center (norm)
    int   swipeDurMs     = 150;    // Swipe:  total gesture duration (ms)

    bool  enabled        = true;
};

// ─── KeyProfile ──────────────────────────────────────────────────────────────

struct KeyProfile {
    std::string packageName;         // "com.garena.game.freefire"
    std::string displayName;         // "Free Fire"  (shown in UI)
    std::vector<KeyBinding> bindings;
};
