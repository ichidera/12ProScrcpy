#pragma once
// keymap_controller.h — runtime engine for the keymap system.
//
// Sits between App's SDL event loop and TouchInjector.
// Responsibilities:
//   • Owns the active KeyProfile (per-app, switched by setProfile()).
//   • Routes SDL events (keydown/keyup, mousemotion, mousebutton) to the
//     correct TouchInjector method for each binding.
//   • Each DPad direction is routed independently, same as any HoldButton -
//     see dpadKeyMap_ below - so all four can be held together for diagonals
//     with no special-cased vector math.
//   • Guards against double-injection (key repeat, multiple bindings on same key).
//   • Exposes videoRect() setters so coordinate conversion always uses the
//     current draw rectangle from App::renderFrame().

#include "keymap_types.h"
#include "keymap_store.h"
#include "touch_injector.h"

#include <SDL.h>
#include <string>
#include <unordered_map>
#include <utility>

class KeymapController {
public:
    explicit KeymapController(std::string serial)
        : injector_(std::move(serial)) {}

    // Re-initialise with a new serial after construction (avoids move-assigning
    // mutex-owning members).  Clears any active profile and state.
    void reset(const std::string& serial) {
        releaseAll();
        profile_ = {};
        keyIndex_.clear();
        mouseIndex_.clear();
        dpadKeyMap_.clear();
        holdActive_.clear();
        injector_ = TouchInjector(serial);
    }

    // ── profile management ────────────────────────────────────────────────────
    void setProfile(const KeyProfile& p) {
        // Release any active touches from the old profile cleanly.
        releaseAll();
        profile_ = p;
        rebuildIndex();
    }

    void clearProfile() { releaseAll(); profile_ = {}; rebuildIndex(); }

    const KeyProfile& profile() const { return profile_; }

    // Save current profile to disk.
    bool saveProfile() const { return keymap_store::save(profile_); }

    // ── video rect (must be kept in sync with App::renderFrame) ──────────────
    // Call this whenever window size, panel width, or fill mode changes.
    void setVideoRect(int x, int y, int w, int h) {
        vx_=x; vy_=y; vw_=w; vh_=h;
    }

    // Current display rotation (0/1/2/3 = 0°/90°/180°/270°), so injected
    // touches land where they visually appear regardless of device
    // orientation. See TouchInjector::setRotation() for why this matters -
    // raw sendevent doesn't get Android's rotation compensation for free.
    void setRotation(int r) { injector_.setRotation(r); }

    // ── SDL event routing ─────────────────────────────────────────────────────
    // Returns true if the controller consumed the event (caller should skip it).
    // keymapActive must be true for any injection to happen (set by App when
    // the editor is closed and a profile is loaded).
    bool handleEvent(const SDL_Event& e, bool keymapActive) {
        if (!keymapActive || profile_.bindings.empty()) return false;

        switch (e.type) {
            case SDL_KEYDOWN:
                if (!e.key.repeat) return onKeyDown(e.key.keysym.sym);
                return false;
            case SDL_KEYUP:
                return onKeyUp(e.key.keysym.sym);
            case SDL_MOUSEMOTION:
                return onMouseMotion(e.motion.xrel, e.motion.yrel);
            case SDL_MOUSEBUTTONDOWN:
                return onMouseButtonDown(e.button.button);
            case SDL_MOUSEBUTTONUP:
                return onMouseButtonUp(e.button.button);
            default:
                return false;
        }
    }

    // Release all active touches (call when cursor unlocked or profile cleared).
    void releaseAll() {
        // Aim
        if (injector_.isAimActive()) injector_.aimClose();

        // Hold buttons AND the 4 DPad direction slots - they're tracked the
        // same way now, so one loop covers both.
        for (auto& [slot, active] : holdActive_) {
            if (active) injector_.holdUp(slot);
        }
        holdActive_.clear();
    }

    TouchInjector& injector() { return injector_; }

private:
    KeyProfile      profile_;
    TouchInjector   injector_;

    // Video rect in renderer pixels (for coordinate mapping).
    int vx_=0, vy_=0, vw_=1, vh_=1;

    // Key index: SDL_Keycode → binding index in profile_.bindings
    std::unordered_map<SDL_Keycode, int> keyIndex_;
    // Mouse button index: SDL_BUTTON_* → binding index
    std::unordered_map<int, int> mouseIndex_;

    // DPad: key → (binding index, which of the 4 directions). Each direction
    // is independently keyed and independently positioned (see DPadPoint in
    // keymap_types.h) - this is just routing, no direction-vector math here
    // at all anymore.
    std::unordered_map<SDL_Keycode, std::pair<int,int>> dpadKeyMap_;

    // Hold button: slot → currently active? Also covers the 4 DPad slots
    // (TouchInjector::kSlotDPadUp..kSlotDPadRight), since a held DPad
    // direction is just a hold-button at its own point.
    std::unordered_map<int,bool> holdActive_;

    void rebuildIndex() {
        keyIndex_.clear(); mouseIndex_.clear(); dpadKeyMap_.clear();
        for (int i=0;i<(int)profile_.bindings.size();++i) {
            const auto& b=profile_.bindings[i];
            if (!b.enabled) continue;
            if (b.type==BindingType::DPad) {
                for (int d=0; d<kDPadDirCount; ++d) {
                    const auto& dp = b.dpad[d];
                    if (dp.enabled && dp.key!=SDLK_UNKNOWN) dpadKeyMap_[dp.key]={i,d};
                }
                continue;
            }
            if (b.key!=SDLK_UNKNOWN)        keyIndex_[b.key]=i;
            if (b.mouseButton!=0)           mouseIndex_[b.mouseButton]=i;
        }
    }

    // ── normalised coords from SDL window position ────────────────────────────
    float toNX(int px) const { return vw_>0?(float)(px-vx_)/vw_:0.5f; }
    float toNY(int py) const { return vh_>0?(float)(py-vy_)/vh_:0.5f; }

    // ── event handlers ────────────────────────────────────────────────────────
    bool onKeyDown(SDL_Keycode k) {
        auto dit=dpadKeyMap_.find(k);
        if (dit!=dpadKeyMap_.end()) {
            auto [bidx,dir]=dit->second;
            const DPadPoint& dp=profile_.bindings[bidx].dpad[dir];
            int slot=dir;  // 0..3 == TouchInjector::kSlotDPadUp..kSlotDPadRight
            holdActive_[slot]=true;
            injector_.holdDown(dp.point.x, dp.point.y, slot);
            return true;
        }
        auto it=keyIndex_.find(k);
        if (it==keyIndex_.end()) return false;
        const KeyBinding& b=profile_.bindings[it->second];
        dispatchDown(b, it->second);
        return true;
    }

    bool onKeyUp(SDL_Keycode k) {
        auto dit=dpadKeyMap_.find(k);
        if (dit!=dpadKeyMap_.end()) {
            int slot=dit->second.second;  // dir index doubles as the slot
            holdActive_[slot]=false;
            injector_.holdUp(slot);
            return true;
        }
        auto it=keyIndex_.find(k);
        if (it==keyIndex_.end()) return false;
        const KeyBinding& b=profile_.bindings[it->second];
        dispatchUp(b, it->second);
        return true;
    }

    bool onMouseButtonDown(int btn) {
        auto it=mouseIndex_.find(btn);
        if (it==mouseIndex_.end()) return false;
        const KeyBinding& b=profile_.bindings[it->second];
        dispatchDown(b, it->second);
        return true;
    }

    bool onMouseButtonUp(int btn) {
        auto it=mouseIndex_.find(btn);
        if (it==mouseIndex_.end()) return false;
        const KeyBinding& b=profile_.bindings[it->second];
        dispatchUp(b, it->second);
        return true;
    }

    bool onMouseMotion(int xrel, int yrel) {
        if (!injector_.isAimActive()) return false;
        // Find the active AimPan/AimAndShoot binding.
        for (auto& b : profile_.bindings) {
            if (!b.enabled) continue;
            if (b.type==BindingType::AimPan||b.type==BindingType::AimAndShoot) {
                injector_.aimMove(xrel,yrel,b.aimSensitivity,b.aimClampRadius,
                                  (float)vw_,(float)vh_);
                return true;
            }
        }
        return false;
    }

    void dispatchDown(const KeyBinding& b, int bindingIdx) {
        switch(b.type) {
            case BindingType::TapPoint:
                injector_.tap(b.center.x, b.center.y,
                              kSlotForExtra(bindingIdx));
                break;
            case BindingType::ShootButton:
                injector_.tap(b.center.x, b.center.y, TouchInjector::kSlotShoot);
                break;
            case BindingType::AimAndShoot:
                // The aim contact is kept open by cursor-lock (F1 in App).
                // A mouse-button press here always means SHOOT — aim drag runs
                // continuously in onMouseMotion. This matches BlueStacks'
                // "Shooting Mode": one finger holds aim, another taps fire.
                injector_.tap(b.center.x, b.center.y, TouchInjector::kSlotShoot);
                break;
            case BindingType::AimPan:
                injector_.aimOpen(b.center.x, b.center.y);
                break;
            case BindingType::HoldButton: {
                int slot=kSlotForExtra(bindingIdx);
                holdActive_[slot]=true;
                injector_.holdDown(b.center.x, b.center.y, slot);
                break;
            }
            case BindingType::Swipe:
                injector_.swipe(b.center.x,b.center.y,
                                b.swipeTo.x,b.swipeTo.y,
                                b.swipeDurMs);
                break;
            case BindingType::DPad:
                break;  // routed entirely through dpadKeyMap_ above
        }
    }

    void dispatchUp(const KeyBinding& b, int bindingIdx) {
        switch(b.type) {
            case BindingType::AimPan:
                injector_.aimClose();
                break;
            case BindingType::HoldButton: {
                int slot=kSlotForExtra(bindingIdx);
                holdActive_[slot]=false;
                injector_.holdUp(slot);
                break;
            }
            default:
                break;  // one-shot bindings don't need a key-up action
        }
    }

    // Assign a stable slot number to TapPoint / HoldButton / Swipe bindings.
    // Slots 0-3 are the DPad directions, 4=Aim, 5=Shoot, so only 6-9 (4
    // slots) are left for these "extra" bindings.
    static int kSlotForExtra(int bindingIdx) {
        return TouchInjector::kSlotBase + (bindingIdx % 4);
    }
};
