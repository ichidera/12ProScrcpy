#pragma once
// FrameBuffer — lock-free triple-buffer for the latest decoded video frame.
//
// Why triple-buffer?
//   The old single-slot design held a mutex while the render thread copied
//   ~3 MB of YUV420P data on every frame, blocking the decode thread from
//   landing the *next* frame during that copy. The result: the render thread
//   always showed a frame that was at least one decode cycle old.
//
//   A triple buffer fixes this with zero mutex contention on the hot path:
//
//     Slot layout:
//       slots[0..2]  — three independent frame buffers
//       write_idx_   — the slot the producer is currently filling
//       ready_idx_   — the slot the producer last finished (atomic swap)
//       read_idx_    — the slot the consumer is currently reading
//
//     Producer (decode thread):
//       1. Pick the slot that isn't read_idx_ and isn't write_idx_ (the
//          "free" slot).  Store it in write_idx_.
//       2. Fill it.
//       3. Atomically swap it into ready_idx_, getting the old ready slot
//          back (which becomes free again).
//
//     Consumer (render thread):
//       1. Atomically swap ready_idx_ with -1 (sentinel), getting the
//          latest-completed slot index.
//       2. If the result is -1, nothing new arrived — return early.
//       3. Otherwise, update read_idx_ and read directly from the slot.
//
//   The consumer *never copies* the pixel data: it reads from the slot in
//   place under a short scoped read-lock that only guards slot metadata
//   (width/height/frameId), not the pixel arrays.  The pixel arrays live
//   in the slot and are only written by the producer when the slot is not
//   the current read_idx_, which is enforced by the protocol above.
//
// Cost: ~3× the RAM of the old design (three full frame buffers instead of
// one).  At 1080×2400 YUV420P that's ~3 × 3.1 MB ≈ 9.3 MB — a negligible
// trade-off on any gaming PC.

#include <array>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <vector>

class FrameBuffer {
public:
    // What the consumer sees.  No pixel ownership — just a view into a
    // slot.  Valid only while the FrameBuffer outlives it AND the consumer
    // calls releaseReadSlot() after it's done with the pixels.
    struct View {
        bool        valid   = false;
        int         width   = 0;
        int         height  = 0;
        uint64_t    frameId = 0;
        const uint8_t* y    = nullptr;  // width * height bytes
        const uint8_t* u    = nullptr;  // (width/2) * (height/2) bytes
        const uint8_t* v    = nullptr;  // (width/2) * (height/2) bytes
    };

    FrameBuffer() {
        readIdx_.store(-1);
        readyIdx_.store(-1);
        writeIdx_.store(0);
    }

    // Producer API — called from the decode thread only.
    // Returns a pointer to writable Y/U/V buffers for the next frame.
    // The caller must call publishFrame() after filling them.
    void beginWrite(int width, int height,
                    uint8_t** yOut, uint8_t** uOut, uint8_t** vOut) {
        int ri = readIdx_.load(std::memory_order_acquire);
        int wi = writeIdx_.load(std::memory_order_relaxed);

        // Find the slot that is neither read_idx_ nor write_idx_.
        int fi = 0;
        for (int i = 0; i < 3; ++i) {
            if (i != ri && i != wi) { fi = i; break; }
        }
        writeIdx_.store(fi, std::memory_order_relaxed);

        Slot& s = slots_[fi];
        const size_t ySize = (size_t)width * height;
        const size_t cSize = (size_t)(width / 2) * (height / 2);
        s.y.resize(ySize);
        s.u.resize(cSize);
        s.v.resize(cSize);
        s.width  = width;
        s.height = height;

        *yOut = s.y.data();
        *uOut = s.u.data();
        *vOut = s.v.data();
    }

    void publishFrame() {
        int wi = writeIdx_.load(std::memory_order_relaxed);
        slots_[wi].frameId = ++frameCounter_;
        // Swap the freshly-written slot into ready_idx_.
        // The old ready slot (if any) becomes free — the producer will
        // pick it up as the next write slot.
        readyIdx_.store(wi, std::memory_order_release);
    }

    // Consumer API — called from the render thread only.
    // Returns a View pointing directly into the slot.
    // If nothing new is available, View.valid == false.
    // The view stays valid until the next call to consume().
    View consume() {
        // Atomically take the ready slot; -1 means nothing new.
        int ri = readyIdx_.exchange(-1, std::memory_order_acq_rel);
        if (ri == -1) return {};

        readIdx_.store(ri, std::memory_order_release);
        const Slot& s = slots_[ri];

        View v;
        v.valid   = true;
        v.width   = s.width;
        v.height  = s.height;
        v.frameId = s.frameId;
        v.y       = s.y.data();
        v.u       = s.u.data();
        v.v       = s.v.data();
        return v;
    }

private:
    struct Slot {
        int      width   = 0;
        int      height  = 0;
        uint64_t frameId = 0;
        std::vector<uint8_t> y, u, v;
    };

    std::array<Slot, 3> slots_;
    std::atomic<int>      readIdx_;   // slot consumer is reading from (-1 = none)
    std::atomic<int>      readyIdx_;  // latest completed slot (-1 = none)
    std::atomic<int>      writeIdx_;  // slot producer is writing into
    uint64_t              frameCounter_ = 0;
};
