// adbmirror - a light ADB screen viewer.
//
// Uses the same core trick scrcpy does -- the phone's dedicated hardware
// video encoder does the work via `adb shell screenrecord`, not repeated
// screenshots -- but ships as a small standalone app with no scrcpy
// binary involved. See README.md for the full pipeline and build/run
// instructions.
//
// Module layout:
//   options.h        - CLI argument parsing
//   frame_buffer.h   - thread-safe holder for the latest decoded frame
//   capturer.h/.cpp  - adb + libavcodec capture/decode thread
//   app.h/.cpp       - SDL window, render loop, cursor lock, input

#include "app.h"
#include "capturer.h"
#include "frame_buffer.h"
#include "options.h"

int main(int argc, char** argv) {
    Options opt = parseOptions(argc, argv);
    if (opt.showHelpAndExit) {
        printUsage();
        return 0;
    }

    FrameBuffer frameBuffer;
    Capturer capturer(frameBuffer, opt.serial, opt.bitrate, opt.size);
    capturer.start();

    App app;
    int result = 1;
    if (app.init()) {
        result = app.run(frameBuffer, capturer);
    }

    capturer.stop();
    return result;
}
