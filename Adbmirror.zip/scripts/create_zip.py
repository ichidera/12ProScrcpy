#!/usr/bin/env python3
"""
Create a zip archive of the project, respecting .gitignore rules.
Overwrites Adbmirror.zip if it exists.
"""

import os
import zipfile
import fnmatch
from pathlib import Path


def parse_gitignore(gitignore_path):
    """Parse .gitignore file and return a list of patterns to ignore."""
    patterns = []
    if os.path.exists(gitignore_path):
        with open(gitignore_path, 'r') as f:
            for line in f:
                line = line.strip()
                # Skip empty lines and comments
                if line and not line.startswith('#'):
                    patterns.append(line)
    return patterns


def should_ignore(path, patterns, root_dir):
    """Check if a path should be ignored based on patterns."""
    rel_path = os.path.relpath(path, root_dir)
    
    for pattern in patterns:
        # Handle directory patterns (ending with /)
        if pattern.endswith('/'):
            dir_pattern = pattern.rstrip('/')
            if fnmatch.fnmatch(rel_path, dir_pattern) or fnmatch.fnmatch(rel_path + '/', dir_pattern + '/'):
                return True
            # Check if the path is inside this directory
            if rel_path.startswith(dir_pattern + os.sep):
                return True
        else:
            # Handle file patterns
            if fnmatch.fnmatch(rel_path, pattern):
                return True
            if fnmatch.fnmatch(os.path.basename(rel_path), pattern):
                return True
    
    return False


def create_project_zip(output_zip, root_dir, gitignore_patterns):
    """Create a zip file of the project, excluding ignored files."""
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(root_dir):
            # Filter out ignored directories
            dirs[:] = [d for d in dirs if not should_ignore(os.path.join(root, d), gitignore_patterns, root_dir)]
            
            for file in files:
                file_path = os.path.join(root, file)
                
                # Skip ignored files
                if should_ignore(file_path, gitignore_patterns, root_dir):
                    continue
                
                # Add file to zip with relative path
                arcname = os.path.relpath(file_path, root_dir)
                zipf.write(file_path, arcname)
                print(f"Added: {arcname}")


def main():
    # Get the project root (parent of scripts directory)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    root_dir = os.path.dirname(script_dir)
    
    # Output zip path
    output_zip = os.path.join(root_dir, 'Adbmirror.zip')
    
    # Parse .gitignore
    gitignore_path = os.path.join(root_dir, '.gitignore')
    patterns = parse_gitignore(gitignore_path)
    
    print(f"Project root: {root_dir}")
    print(f"Output zip: {output_zip}")
    print(f"Ignoring patterns: {patterns}")
    print()
    
    # Remove existing zip if it exists
    if os.path.exists(output_zip):
        os.remove(output_zip)
        print(f"Removed existing {output_zip}")
    
    # Create the zip
    create_project_zip(output_zip, root_dir, patterns)
    
    print()
    print(f"✓ Successfully created {output_zip}")


if __name__ == '__main__':
    main()
