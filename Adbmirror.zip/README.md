# adbmirror

A light ADB screen viewer. It uses the same core trick scrcpy does — the
**phone's dedicated hardware video encoder** does the work, not repeated
screenshots — but ships as a small standalone app with no scrcpy binary
involved.

```
adb exec-out screenrecord --output-format=h264 -   (device: HW encode)
   -> raw H264 over the adb pipe
   -> libavcodec decode (PC)
   -> SDL2 window, scaled to fit, aspect-ratio preserved
```

## Project layout

```
adbmirror/
  CMakeLists.txt
  README.md
  src/
    main.cpp         entry point: wires Options + Capturer + App together
    options.h         CLI argument parsing
    frame_buffer.h    thread-safe holder for the latest decoded frame
    capturer.h/.cpp    adb + libavcodec capture/decode thread
    app.h/.cpp         SDL window, render loop, cursor lock, input
```

`FrameBuffer` knows nothing about adb or H264, and `App` knows nothing
about either one — they only talk through `FrameBuffer::Snapshot`. That
keeps each piece independently readable/testable and means swapping the
capture strategy later (e.g. a root-only SurfaceFlinger hook) only
touches `capturer.*`.

## Controls

| Key | Action |
|---|---|
| `F1` | Toggle cursor lock — confines **and hides** your mouse cursor |
| `F2` | Toggle fill (crop to fill window, no black bars) / fit (letterboxed) |
| `F3` | Toggle the left-edge control panel |
| `F4` | Open/close the keymap editor (place keyboard/mouse → touch bindings) |
| `Esc` | Unlock the cursor if locked, otherwise quit |
| `Q` | Quit |

Drag the window edges or maximize it — by default the image scales up to
**fill the window completely** (cropping whatever spills past the edges)
so there's never a black bar, while the picture itself is never
stretched or distorted. Press `F2` if you'd rather see the whole screen
letterboxed instead.

**Rotation:** when the foreground app on the phone switches between
portrait and landscape, the window automatically resizes its video area
to match the new aspect ratio — the same way scrcpy follows device
rotation. Without this, "fill" mode would keep cropping to the old
aspect and cut off a large chunk of the newly-rotated screen. This also
keeps keymap points stable across rotations, fullscreen, and manual
resizing: they're stored normalised to the video image itself (0..1
across its width/height), not to raw window pixels, so as long as the
window is showing the whole picture their position is exact regardless
of window size. The one place this could still go wrong — "fill" mode
cropping part of the screen out of view while you're trying to *place*
a point on it — is handled by always switching to "fit" (full picture,
letterboxed) while the keymap editor (`F4`) is open, regardless of your
normal `F2` preference, then restoring your preference on close.

### Keymap system

`F4` opens the editor. Click empty space to add a binding, drag a point
to reposition it, click a point to select it and open its toolbar
(delete / cycle type / set key / done). Bindings save automatically per
foreground package under `./keymaps/<package>.json` and reload when you
switch back to that app.

**DPad** is 4 completely independent buttons — up/down/left/right —
each with its own position and its own key, not a single joystick with
computed corners. Drag each one wherever you want, bind each to
whatever key you want, and any combination can be held together for
diagonals. Defaults to W/A/S/D laid out around wherever you clicked;
rebind or reposition any of the four independently from there.

**Rotation-aware touch placement.** This app injects raw `sendevent`
straight into the touchscreen driver (see
`docs/real-device-adb-sendevent.md`), bypassing Android's input stack
entirely. A real touch gets automatically rotated by Android to match
the current screen orientation before an app ever sees it; raw
`sendevent` doesn't get that for free, so the app polls the device's
current rotation (`dumpsys input`) and compensates before every
injected touch. This is based on the standard Android rotation
convention and hasn't been verified against every device/Android build
— if a placed point still lands in the wrong spot after this, enable
**Settings → Developer options → Show taps** on the device to see
exactly where injected touches land, and check `src/touch_injector.h`'s
`toRawX`/`toRawY`: the fix is almost always swapping the `rotation==1`
and `rotation==3` cases (they're mirror images of each other), not
re-deriving the transform from scratch.

### Control panel

A small tab sits flush against the left edge of the window at all
times. Click it (or press `F3`) to slide it out — the **window itself
grows wider** to reveal a drawer with four buttons, so the mirrored
screen shifts over rather than getting covered. Closing it (click the
tab again, or `F3`) shrinks the window back down.

| Button | Action |
|---|---|
| 🔊 `+` | Volume up |
| 🔊 `−` | Volume down |
| ⏻ | Power button (locks/wakes the screen, same as a real press) |
| ▣ | Screenshot — saved as `screenshots/adbmirror-YYYYMMDD-HHMMSS.png`, relative to wherever you launched `adbmirror` from (the folder is created automatically if it doesn't exist yet) |

The screenshot button flashes green on success or red if the pull
failed (e.g. device disconnected mid-capture).

**This one's built for a specific rooted device**, not "phones" in
general. Volume and power go in via root + `setenforce 0` + raw
`sendevent` straight into that device's PMIC/gpio-keys input nodes —
see `docs/real-device-adb-sendevent.md` for why the ordinary
`adb shell input keyevent` path doesn't work here (this device's
SELinux policy blocks it). If you ever point this at a different
device, the three device-node/keycode constants at the top of
`src/adb_control.cpp` are the only things that need to change —
find the equivalents the same way that doc does
(`adb shell su -c "cat /proc/bus/input/devices"` and
`ls -la /dev/input/`). Screenshot still uses plain `screencap`, since
that doesn't need root on this device.

Panel clicks need an unlocked, visible cursor, so unlock it with `F1`
first if you've been driving the mirror in cursor-locked mode.

## Requirements

- CMake ≥ 3.10, a C++17 compiler, `pkg-config`
- SDL2 development libraries
- **FFmpeg decode libraries**: `libavcodec`, `libavutil`, `libswscale`
  (only the decoder is used — no encoding, no muxing, no ffmpeg CLI)
- `adb` on your `PATH`, USB debugging enabled and authorized on the phone

## Build

### Linux

```bash
sudo apt install libsdl2-dev libavcodec-dev libavutil-dev libswscale-dev cmake build-essential pkg-config
mkdir build && cd build
cmake ..
cmake --build .
```

### macOS

```bash
brew install sdl2 ffmpeg cmake pkg-config
mkdir build && cd build
cmake ..
cmake --build .
```

### Windows — pick ONE toolchain, don't mix them

`pkg-config` will happily resolve SDL2/FFmpeg from an MSYS2/MinGW
install even while CMake is targeting MSVC. That combination fails to
compile — MinGW's headers use GCC-only syntax that `cl.exe` rejects —
and it does so with a wall of unrelated-looking errors deep inside
`<stdio.h>`/`<math.h>`. `CMakeLists.txt` here detects that specific
mismatch and stops with a clear message, but the fix is to just use one
consistent toolchain in the first place:

**Option A — MSYS2 MinGW, all the way through (simplest if you already
use MSYS2):**

Open the **"MSYS2 MinGW x64"** shell specifically (not a plain
PowerShell/CMD, and not "MSYS2 UCRT64" or "MSYS2 Clang64" — those are
different toolchains too):

```bash
pacman -S mingw-w64-x86_64-toolchain mingw-w64-x86_64-cmake \
          mingw-w64-x86_64-ninja mingw-w64-x86_64-pkgconf \
          mingw-w64-x86_64-sdl2 mingw-w64-x86_64-ffmpeg
cmake -G "Ninja" -B build
cmake --build build
```

**Option B — MSVC + vcpkg, all the way through:**

```powershell
vcpkg install sdl2:x64-windows ffmpeg[avcodec,avutil,swscale]:x64-windows
cmake -B build -DCMAKE_TOOLCHAIN_FILE=<vcpkg-root>/scripts/buildsystems/vcpkg.cmake
cmake --build build --config Release
```

Don't run plain `cmake .` in a PowerShell terminal on a machine that
also has MSYS2 on `PATH` — CMake will silently pick the MSVC generator
while `pkg-config` (from MSYS2) resolves MinGW libraries, which is
exactly the mismatch above.

## Run

1. Confirm the device is visible:
   ```
   adb devices
   ```
2. Run it:
   ```
   ./adbmirror
   ```
   Options:
   ```
   ./adbmirror -s <serial>          # pick device when more than one is attached
   ./adbmirror -b 4M                # lower bitrate (default 8M)
   ./adbmirror -r 720x1600          # cap capture resolution
   ```
3. `F1` to lock/unlock the cursor to the window at any time.

## Why this is light on the device

- No PNG screenshot loop — Android's `screencap` composites the screen
  *and* software-encodes a PNG on every single call, which is the
  expensive part on the phone. `screenrecord` instead uses the phone's
  dedicated hardware video encoder (MediaCodec), the same silicon block
  used for camera recording — near-zero extra CPU load, much better for
  battery.
- No extra binaries pushed to the device (no minicap/minitouch server,
  no scrcpy-server.jar) — only the stock `screenrecord` shell command
  that ships with every Android build.
- All decoding happens on your PC, using just the FFmpeg *decoder*
  (`libavcodec`), not the full ffmpeg toolchain.

## Known limitation

Android's `screenrecord` has a built-in ~180 second maximum recording
time per invocation. When it stops, the pipe closes, and `Capturer`
automatically reconnects — you'll see a brief (well under a second)
hiccup roughly every 3 minutes. This is an Android platform limit, not
something fixable from the client side without a rooted/patched
`screenrecord`.

## Root-specific alternatives (not implemented here)

With root you could go further and hook SurfaceFlinger directly for
event-driven, only-on-change frames (the minicap approach) — the lowest
possible overhead, but the binary must be compiled per device ABI/SDK
and the project is largely unmaintained on modern Android, so it wasn't
worth the added complexity here. If you want it later, it's a
self-contained change to `capturer.h`/`capturer.cpp` only.